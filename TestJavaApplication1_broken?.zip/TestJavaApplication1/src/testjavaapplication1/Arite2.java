/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Arite2 extends Operation {
    protected NonParametre operande1;
    protected NonParametre operande2;
    
    public Arite2(Parametre parametre, NonParametre operande1, NonParametre operande2) {
        super(parametre);
        this.operande1 = operande1;
        this.operande1.setParent(this);
        this.operande2 = operande2;
        this.operande2.setParent(this);
    }
    
    protected float fct1(float x, float y) {
        return x*y;
    }
    
    protected float d_fct1(float df_dx) {
        float x = this.operande1.getValeur();
        if (df_dx == x) return this.operande2.getValeur();
        else return x;
    }
    
    protected float fct2(float x, float y) {
        return x+y;
    }
    
    protected float d_fct2(float df_dx) {
        return 1;
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) {
            //System.out.println("valeur dejà calculée.");
            return this.valeur;
        }
        else {
            float a = this.parametre.getValeur();
            float x = this.operande1.getValeur();
            float y = this.operande2.getValeur();
            //System.out.println("calcul de valeur :");
            //System.out.println(a + " * " + x + " * " + y + " + " + (1-a) + " * (" + x + " + " + y + ")");
            this.valeur = a*fct1(x, y) + (1 - a)*fct2(x, y);
            this.valeurCalclulee = true;
            return this.valeur;
        }
    }
    
}
