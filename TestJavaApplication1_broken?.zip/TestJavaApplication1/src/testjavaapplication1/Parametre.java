
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Parametre extends Arbre {

    public Parametre() {
        super();
        this.valeur = (float)Math.random();
        this.valeurCalclulee = true;
    }
    
    @Override
    float fctGradient() {
        Arbre parentTmp = this.parent;
        if (parentTmp instanceof Arite1) {
            Arite1 A = (Arite1)parentTmp;
            float x = A.operande.getValeur();
            //float x = A.getValeur();
            return A.fct1(x) - A.fct2(x);
        } else if (parentTmp instanceof Arite2) {
            Arite2 A = (Arite2)parentTmp;
            float x = A.operande1.getValeur();
            float y = A.operande2.getValeur();
            //return A.d_fct1(x, y) - A.d_fct2(x, y);
            return 1;
        } else {
            System.out.println("?????? (parametre fct gradient)");
            return 420;
        }
    }

    @Override
    public float getValeur() {
        return this.valeur;
    }
    
    public void update(float resultatAttendu) {
        this.resetValeur();
        //float grad = this.calculGradient(resultatAttendu);
        //System.out.println(grad);
        this.valeur -= this.calculGradient(resultatAttendu);
        if (this.valeur < 0) this.valeur = 0;
        else if (this.valeur > 1) this.valeur = 1;
        this.valeurCalclulee = true;
    }

}
