/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Arite1 extends Operation {
    
    protected NonParametre operande;
    
    public Arite1(Parametre parametre, NonParametre operande) {
        super(parametre);
        this.operande = operande;
        this.operande.setParent(this);
    }
    
    protected float fct1(float x) {
        return (float) (1.0/x);
    }
    protected float d_fct1(float x) {
        return (float)(-1.0/(x*x)); ///MODIF ICI!! : mauvaise dérivée! (1/x²) -> (-1/x²)
    }
    
    protected float fct2(float x) {
        return x;
    }
    protected float d_fct2(float x) {
        return 1;
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) return this.valeur; 
        else {
            float a = this.parametre.getValeur();
            float x = this.operande.getValeur();
            //System.out.println(a + " * 1.0/" + x + " + (1" + (-a) + ") * " + x );
            this.valeur = a*fct1(x) + (1-a)*fct2(x);
            //this.valeurCalclulee = true;
            return this.valeur;
        }
    }  
}
