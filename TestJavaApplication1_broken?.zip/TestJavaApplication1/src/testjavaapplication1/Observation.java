/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Observation extends NonParametre {

    public Observation() {
        super();
    }

    @Override
    float fctGradient() {
        System.out.println("ceci n'est supposé être utilisé!");
        return 1;
    }
    
    @Override
    public float getValeur() {
        if (!this.valeurCalclulee) {
            System.out.println("ERREUR : valeur non calculée (observation)");
            this.valeur = (float)Math.random();
        }
        return this.valeur;
    }

    public void setValeur(float valeur) {
        if (this.valeur != valeur) {
            this.resetValeur();
            this.valeur = valeur;
            this.valeurCalclulee = true;
        }
    }   
}
