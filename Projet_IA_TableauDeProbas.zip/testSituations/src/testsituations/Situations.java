/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testsituations;

/**
 *
 * @author garrprivate
 */
public class Situations {
    
    private TableauNEntrees probasActions;
    private TableauNEntrees scores;
    private TableauNEntrees probasSituations;
    private int[] dimensionsObservations;
    private int[] dimensionsActions;
    private int nbActions;
    private int nbObservations;
    private int nbSituations;
    
    public Situations(int nbObs, int nbAct, int resolution) {
        int dimensions[] = new int[2*nbObs + nbAct];
        
        for (int i = 0 ; i < dimensions.length ; i++) {
            dimensions[i] = resolution;
        }
        
        this.probasActions = new TableauNEntrees(dimensions);
        
        this.probasActions.SetValeurs((float)(1.0/Math.pow(resolution, nbObs)));
        this.nbActions = nbAct;
        this.nbObservations = nbObs;
        
        int observations[] = new int[nbObs];
        for (int i = 0 ; i < observations.length ; i++) {
            observations[i] = resolution;
        }
        
        this.dimensionsActions = new int[nbActions];
        for (int i = 0 ; i < this.dimensionsActions.length ; i++) {
            this.dimensionsActions[i] = resolution;
        }
        
        this.dimensionsObservations = new int[nbObs];
        System.arraycopy(observations, 0, this.dimensionsObservations, 0, this.dimensionsObservations.length);
        
        this.scores = new TableauNEntrees(observations);
        this.scores.SetValeurs(0);
    }
    
    public Situations(int actions[], int observations[]) {
        int dimensions[] = this.MergeTabs(actions, observations, observations);
        
        this.probasActions = new TableauNEntrees(dimensions);
        
        this.dimensionsObservations = new int[observations.length];
        System.arraycopy(observations, 0, this.dimensionsObservations, 0, this.dimensionsObservations.length);
        
        this.dimensionsActions = new int[actions.length];
        System.arraycopy(actions, 0, this.dimensionsActions, 0, this.dimensionsActions.length);
        
        this.nbSituations = 1;
        for (int i = 0 ; i < observations.length ; i++) {
            this.nbSituations *= observations[i];
        }
        
        this.nbActions = actions.length;
        this.nbObservations = observations.length;

        this.probasActions.SetValeurs((float)(1.0/this.nbSituations));
        
        this.scores = new TableauNEntrees(observations);
        this.scores.SetValeurs(0);
    }
    
    private int[] MergeTabs(int action[], int situationDepuis[], int situationVers[]) {
        int coordonees[] = new int[action.length + 2*situationVers.length];
        
        System.arraycopy(action, 0, coordonees, situationVers.length, action.length);
        System.arraycopy(situationDepuis, 0, coordonees, 0, situationVers.length); 
        System.arraycopy(situationVers, 0, coordonees, situationVers.length + action.length, situationVers.length);
        
        return coordonees;
    }
    
    private int[] MergeTabs(int action[], int situationDepuis[]) {
        int coordonees[] = new int[action.length + situationDepuis.length];
        
        System.arraycopy(action, 0, coordonees, this.nbObservations, this.nbActions);
        System.arraycopy(situationDepuis, 0, coordonees, 0, this.nbObservations);
        
        return coordonees;
    }
    
    public void SetValeursParDimension(int action[], int situationDepuis[], int situationVers[], float valeur) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            this.probasActions.SetValeursParDimension(coordonees, valeur);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
        }   
    } //test only!!
    
    public float GetValeursParDimension(int action[], int situationDepuis[], int situationVers[]) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            return this.probasActions.GetValeur(coordonees);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
            return 420;
        }   
    } //test only!!
    
    public void IncrementerProbaConditionnelle (int action[], int situationDepuis[], int situationVers[], float pas) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            float valeur = this.probasActions.GetValeur(coordonees) + pas;
            this.probasActions.SetValeursParDimension(coordonees, valeur);
            int coordonees2[] = this.MergeTabs(action, situationDepuis);
            this.probasActions.ChangeValeursDivisionParDimension(coordonees2, 1+pas);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
        }   
    }
    
    public void AfficherProbas(int action[], int situationDepuis[]) {
        int coordonees[] = this.MergeTabs(action, situationDepuis);
        this.probasActions.Affiche(coordonees);
    }
    
    public void AfficherScores() {
        this.scores.Affiche();
    }
    
    public void SetScore(int coordonees[], float valeur) {
        this.scores.SetValeursParDimension(coordonees, valeur);
    }
    
    public float GetScoreParActionParSituation(int action[], int situation[]) {
        if (action.length == this.nbActions && situation.length == this.nbObservations) {
            int coordonees[] = new int[this.nbObservations];
            
            for (int i = 0 ; i < coordonees.length ; i++) {
                coordonees[i] = 0;
            }
            
            float scoreProba = 0;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                                
                int coords[] = this.MergeTabs(action, situation, coordonees);
                float probabilite = this.probasActions.GetValeur(coords);
                float scoreSituation = this.scores.GetValeur(coordonees);

                scoreProba += probabilite * scoreSituation;
                //System.out.println(probabilite + " * " + scoreSituation + " = " + probabilite * scoreSituation + " => " + scoreProba);
                
                coordonees[cpt]++;
                while (cpt != coordonees.length && coordonees[cpt] == this.dimensionsObservations[cpt]) {
                    coordonees[cpt] = 0;
                    cpt++;
                    if (cpt == coordonees.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    coordonees[cpt]++;
                }
                
                cpt = 0;
            } while (!debordement);
            return scoreProba;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour les actions ou la situation!!");
            return 420;
        }
    }
    
    public int[] GetMeilleureActionParSituation(int[] situation) {
        if (situation.length == this.nbObservations) {

            int[] actions = new int[this.nbActions];
            int[] meilleuresActions = new int[this.nbActions];
            
            for (int i = 0 ; i < actions.length ; i++) {
                actions[i] = 0;
                meilleuresActions[i] = -1;
            }
            
            float meilleurScore = -420000;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                float score = this.GetScoreParActionParSituation(actions, situation);
                //System.out.println(score);
                if (score > meilleurScore) {
                    meilleurScore = score;
                    System.arraycopy(actions, 0, meilleuresActions, 0, meilleuresActions.length);
                }
                
                actions[cpt]++;
                while (cpt != actions.length && actions[cpt] == this.dimensionsActions[cpt]) {
                    actions[cpt] = 0;
                    cpt++;
                    if (cpt == actions.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    actions[cpt]++;
                }
                cpt = 0;
            } while (!debordement);
            //System.out.println(meilleurScore);
            return meilleuresActions;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour la situations!!");
            int tab[] = {-1};
            return tab;
        }
    }
    
}
