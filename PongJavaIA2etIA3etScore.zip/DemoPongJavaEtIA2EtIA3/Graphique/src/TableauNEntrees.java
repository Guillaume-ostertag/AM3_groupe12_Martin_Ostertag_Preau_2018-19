/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class TableauNEntrees {
    private TableauNEntrees[] T;
    private int profondeur;
    private float valeur;
    
    private void Constructeur(int dimensions[], int N) {
        this.profondeur = dimensions.length - N;
        //System.out.println(this.profondeur);
        if (N < dimensions.length) {
            int n = dimensions[N];
            this.T = new TableauNEntrees[n];
            for (int i = 0 ; i < n; i++) {
                this.T[i] = new TableauNEntrees(dimensions, N+1);
            }
        } else if (N == dimensions.length) {
            Compteur.inc();
            //System.out.println("bedrock");
        } else {
            Compteur.sout();
            System.out.println("ERROR!");
        }
    }
    
    public TableauNEntrees(int dimensions[]) {
        boolean valide = true;
       
        if (dimensions.length == 0) {
            valide = false;
            System.out.println("pas de tableau vide pour les dimensions!!");
        }
        
        for (int i = 0 ; i < dimensions.length ; i++) {
            if (dimensions[i] < 1) {
                valide = false;
                System.out.println("pas de zéro ou moins dans les dimensions!!");
                break;
            }
        }
        
        if (valide) this.Constructeur(dimensions, 0);
    }
    
    private TableauNEntrees(int[] dimensions, int N) {    
        this.Constructeur(dimensions, N);
    }
    
    public void SetValeurs(float valeur) {
        int tab[] = {};
        this.SetValeursParDimension(tab, valeur, 0);
    }
    
    public void SetValeursParDimension(int coordonees[], float valeur) {
        if (coordonees.length > this.profondeur) {
            System.out.println("ERROR! plus de coordonnées que de dimensions!!");
        } else {
            this.SetValeursParDimension(coordonees, valeur, 0);
        }
    }
    
    private void SetValeursParDimension(int coordonees[], float valeur, int cpt) {
        if (cpt < coordonees.length) {
            int c = coordonees[cpt];
            if (c < this.T.length) {
                this.T[c].SetValeursParDimension(coordonees, valeur, cpt+1);
            } else if (c < 0) {
                System.out.println("ERROR!! pas de valeurs petites que 0 dans les coordonées!!");
            }  else {
                System.out.println("ERROR!! pas de valeurs plus grandes ou egales que les dimensions dans les coordonées!!");
            }
        } else if (cpt == coordonees.length) {
            if (this.T != null) {
                for (TableauNEntrees Ti : this.T) {
                    Ti.SetValeursParDimension(coordonees, valeur, cpt);
                }
            } else if (this.T == null) {
                this.valeur = valeur;
            } else {
                System.out.println("???");
            }
        }   
    }
    
    public void ChangeValeursDivision(float valeur) {
        int tab[] = {};
        this.ChangeValeursDivisionParDimension(tab, valeur, 0);
    }
    
    public void ChangeValeursDivisionParDimension(int coordonees[], float valeur) {
        if (coordonees.length > this.profondeur) {
            System.out.println("ERROR! plus de coordonnées que de dimensions!!");
        } else {
            this.ChangeValeursDivisionParDimension(coordonees, valeur, 0);
        }
    }
    
    private void ChangeValeursDivisionParDimension(int coordonees[], float valeur, int cpt) {
        if (cpt < coordonees.length) {
            int c = coordonees[cpt];
            if (c < this.T.length) {
                this.T[c].ChangeValeursDivisionParDimension(coordonees, valeur, cpt+1);
            } else {
                System.out.println("ERROR!! pas de valeurs plus grandes ou egales que les dimensions dans les coordonées!!");
            }
        } else if (cpt == coordonees.length) {
            if (this.T != null) {
                for (TableauNEntrees Ti : this.T) {
                    Ti.ChangeValeursDivisionParDimension(coordonees, valeur, cpt);
                }
            } else if (this.T == null) {
                this.valeur = this.valeur/valeur;
            } else {
                System.out.println("???");
            }
        }   
    }
    
    public void Affiche() {
        int tab[] = {};
        this.Affiche(tab, 0);
    }
    
    public void Affiche(int coordonees[]) {
        if (coordonees.length > this.profondeur) {
            System.out.println("ERROR! plus de coordonnées que de dimensions!!");
        } else {
            this.Affiche(coordonees, 0);
        }
    }
    
    private void Affiche(int coordonees[], int cpt) {
        if (cpt < coordonees.length) {
            int c = coordonees[cpt];
            if (c < this.T.length) {
                this.T[c].Affiche(coordonees, cpt+1);
            } else {
                System.out.println("ERROR!! pas de valeurs plus grandes ou egales que les dimensions dans les coordonées!!");
            }
        } else if (cpt == coordonees.length) {
            if (this.profondeur > 0) {
                for (TableauNEntrees Ti : this.T) {
                    if (this.profondeur > 1) System.out.println("");
                    Ti.Affiche(coordonees, cpt);
                }
            } else {
                System.out.println(this.valeur);
            }
        } else {
            System.out.println("ERROR !!?");
        }
    }
    
    public float GetValeur(int coordonees[]) {
        if (coordonees.length != this.profondeur) {
            System.out.println("ERROR : pas le bon nombre de coordonees!!");
            return 420;
        } else {
            return this.GetValeur(coordonees, 0);
        }
    }
    
    private float GetValeur(int coordonees[], int cpt) {
        if (this.profondeur > 0) {
            int c = coordonees[cpt];
            if (c >= this.T.length) {
                System.out.println("ERROR!! pas de valeurs plus grandes ou egales que les dimensions dans les coordonées!!");
                return 420;
            } else if (c < 0) {
                System.out.println("ERROR!! pas de valeurs petites que 0 dans les coordonées!!");
                return 420;
            } else {
                return this.T[c].GetValeur(coordonees, cpt+1);
            }
        } else if (this.profondeur == 0) {
            return this.valeur;
        } else {
            System.out.println("ERROR : ????????????");
            return 420;
        }
    }
    
    public int GetNombreElements() {
        return this.GetNombreElements(this.profondeur, 0);
    }
    
    public int GetNombreElements(int profondeurMax) {
        return this.GetNombreElements(profondeurMax, 0);
    }
            
    public int GetNombreElements(int profondeurMax, int profondeurMin) {
        if (profondeurMin < 0) {
            System.out.println("ERROR : la profondeur doit être à 0 minimum!!");
            return 420; 
        } else {
            if (this.profondeur > profondeurMax) {
                return this.T[0].GetNombreElements(profondeurMax, profondeurMin);
            } else if (this.profondeur <= profondeurMax && this.profondeur > profondeurMin) {
                return this.T.length * this.T[0].GetNombreElements(profondeurMax, profondeurMin);
            } else if (this.profondeur == profondeurMin) {
                return 1;
            } else {
                System.out.println(profondeurMax + " " + this.profondeur + " " + profondeurMin);
                System.out.println("???");
                return 420; 
            }
        }
    }
    
}
