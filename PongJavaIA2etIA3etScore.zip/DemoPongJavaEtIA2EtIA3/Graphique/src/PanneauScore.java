
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Baptiste
 */
public class PanneauScore extends JPanel { 
  
    
  boolean debut = true;
  
  public List<Integer> listeScoreMax = new LinkedList<>();
  
  
  public PanneauScore (){
  
      
      
  }
  @Override
  public void paintComponent(Graphics g){
      
      
      g.setColor(Color.WHITE);
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
         
      
      g.setColor(Color.BLACK);
    
      g.fillRect(10,10,5,this.getHeight()-30); //(x,y,longueur en x, hauteur en y
      g.fillRect(10,this.getHeight()-20,this.getWidth()-30,5); //(x,y,longueur en x, hauteur en y
      
      g.setColor(Color.RED);
      g.fillRect(10,this.getHeight()-20,5,5);
    
      
      int compteurX = 20;
      
      while (compteurX<this.getWidth()-30){
          g.setColor(Color.GREEN);
          g.fillRect(compteurX,this.getHeight()-20,2,5);
          
          compteurX+=10;
      }
      int compteurY = 20;
      while (compteurY<this.getHeight()-20){
          g.fillRect(compteurY,10,2,5);
          compteurY+=10;
      }
      
      
     
      
      int compteurTemps = 0;
      
      for(Integer i:listeScoreMax){
          g.setColor(Color.RED);
          g.fillRect((int)compteurTemps*(this.getWidth()/listeScoreMax.size()),(int)this.getHeight()-i-30, 10,10);
          compteurTemps+=1;
      }
      
      
  }      
  
  public void update(){
       
       
}
}
