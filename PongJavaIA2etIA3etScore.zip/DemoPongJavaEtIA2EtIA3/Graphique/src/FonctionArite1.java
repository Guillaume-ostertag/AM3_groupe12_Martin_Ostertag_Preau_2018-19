/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class FonctionArite1 {
    FA1f f;
    FA1f df;

    public FonctionArite1(FA1f f, FA1f df) {
        this.f = f;
        this.df = df;
    }
    
    public interface FA1f {
        float eval(float x);
    }
}
