/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class Arite2 extends Operation {
    
    protected NonParametre operande1;
    protected NonParametre operande2;
    static protected FonctionArite2 op1;
    static protected FonctionArite2 op2;
    
    static public void InitOperations(FonctionArite2 op1, FonctionArite2 op2) {
        Arite2.op1 = op1;
        Arite2.op2 = op2;
    }
    
    public Arite2(Parametre parametre, NonParametre operande1, NonParametre operande2) {
        super(parametre);
        this.operande1 = operande1;
        this.operande1.setParent(this);
        this.operande2 = operande2;
        this.operande2.setParent(this);
    }

    protected boolean estOperande1(Arbre A) {
        return A == this.operande1;
    }
    
    protected boolean estOperande2(Arbre A) {
        return A == this.operande2;
    }
    
    @Override
    public float getValeur() {
        if (this.valeurCalclulee) {
            return this.valeur;
        }
        else {
            float a = this.parametre.getValeur();
            float x1 = this.operande1.getValeur();
            float x2 = this.operande2.getValeur();
            this.valeur = (a*Arite2.op1.f.eval(x1, x2) + (Arbre.range - a)*Arite2.op2.f.eval(x1, x2))/Arbre.range;
            return this.valeur;
        }
    }
    
}
