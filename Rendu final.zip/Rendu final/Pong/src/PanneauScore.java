
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Baptiste
 */
public class PanneauScore extends JPanel { 
  
    
  boolean debut = true;
  
  public List<Integer> listeScoreMax_2 = new LinkedList<>();
  public List<Integer> listeScoreMax_3 = new LinkedList<>();
  public List<Integer> listeScoreMax_4 = new LinkedList<>();
  public List<Integer> listeScoreMax_5 = new LinkedList<>();
  
  public PanneauScore (){
  
      
      
  }
  @Override
  public void paintComponent(Graphics g){
      
      
      g.setColor(Color.WHITE);
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
         
      
      g.setColor(Color.BLACK);
    
      g.fillRect(10,10,5,this.getHeight()-30); //(x,y,longueur en x, hauteur en y
      g.fillRect(10,this.getHeight()-20,this.getWidth()-30,5); //(x,y,longueur en x, hauteur en y
      
      g.setColor(Color.RED);
      g.fillRect(10,this.getHeight()-20,5,5);
    
      
     /** int compteurY = 20;
      while (compteurY<this.getHeight()-20){
          g.fillRect(compteurY,10,2,5);
          compteurY+=10;
      }**/
      
      
     
      
      int compteurTemps = 0;
      
      for(Integer i:listeScoreMax_2){
          g.setColor(Color.RED);
          g.fillRect((int)(compteurTemps*((double)this.getWidth()/listeScoreMax_2.size())),(int)this.getHeight()-(i*1)-30, 5,5);
          compteurTemps+=1;
      }
      
       compteurTemps = 0;
       
      for(Integer i:listeScoreMax_3){
          g.setColor(Color.BLUE);
          g.fillRect((int)(compteurTemps*((double)this.getWidth()/listeScoreMax_3.size())+5),(int)this.getHeight()-(i*1)-30, 5,5);
          compteurTemps+=1;
      }
      
       compteurTemps = 0;
       
      for(Integer i:listeScoreMax_4){
          g.setColor(Color.ORANGE);
          g.fillRect((int)(compteurTemps*((double)this.getWidth()/listeScoreMax_4.size())-5),(int)this.getHeight()-(i*1)-30, 5,5);
          compteurTemps+=1;
      }
      
       compteurTemps = 0;
       
      for(Integer i:listeScoreMax_5){
          g.setColor(Color.PINK);
          g.fillRect((int)(compteurTemps*((double)this.getWidth()/listeScoreMax_4.size())-10),(int)this.getHeight()-(i*1)-30, 5,5);
          compteurTemps+=1;
      }
  }      
  
  public void update(){
       
       
}
}
