
import java.awt.Color;
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class Main {
    public static void main (String[] args){
               
        /////////////////////////////////////////////////////////:
        //IA3
        
        int[] dimensionsObservation = {9,9,5,2,2};
        int[] dimensionsAction = {3};
        
        IA cerveau = new IA(dimensionsAction, dimensionsObservation);
        
        int[] observation = new int[dimensionsObservation.length];
        int[] action = new int[dimensionsAction.length];
        int[] observationPrec = new int [observation.length];
        
        int [][] actionPrec = new int [1][action.length];
        for (int j = 0; j < action.length; j++) {
                actionPrec[0][j] = 0;
            
        }
        
        for (int i = 0; i < dimensionsObservation[0]; i++) {
            for (int j = 0; j < dimensionsObservation[1]; j++) {
                for (int k = 0; k < dimensionsObservation[2]; k++) {
                    for (int l = 0; l < dimensionsObservation[3]; l++) {
                        for (int m = 0; m < dimensionsObservation[4]; m++) {
                            int[] tab = {i, j, k, l, m};
                            
                            //if (k == dimensionsObservation[2]-1) cerveau.SetScore(tab, -10);
                            if (i == j)                          cerveau.SetScore(tab,  20);
                        }
                    }
                }
            }
        }
        
        int deplacement_Lineaire = 0; // utile pour l'ialéatoire
        
        ////////////////////////////////////////////////////
        //IA2
        
        
        FonctionArite2 addition       = new FonctionArite2((a, b) -> a+b, (a, b) ->  1, (a, b) ->  1);
        FonctionArite2 soustraction   = new FonctionArite2((a, b) -> a-b, (a, b) -> -1, (a, b) -> -1);
        FonctionArite2 multiplication = new FonctionArite2((a, b) -> a*b, (a, b) ->  b, (a, b) ->  a);
        FonctionArite2 minimum        = new FonctionArite2((a, b) -> Math.min(a, b), (float a, float b) -> a < b ? 1 : b, (a, b) -> a < b ? a : 1);
        
        FonctionArite1 sinus    = new FonctionArite1((a) -> (float)Math.sin(a), (a) -> (float)Math.cos(a));
        FonctionArite1 inverse  = new FonctionArite1((a) -> 1/a, (a) -> -1/(a*a));
        FonctionArite1 negatif  = new FonctionArite1((a) -> -a,  (a) -> -1); //somehow brocken??
        FonctionArite1 carre    = new FonctionArite1((a) -> a*a, (a) -> 2*a);
        FonctionArite1 identite = new FonctionArite1((a) -> a,   (a) -> 1);
        FonctionArite1 elemNeutreAdd  = new FonctionArite1((a) -> 0,   (a) -> 0);
        FonctionArite1 elemNeutreMult = new FonctionArite1((a) -> 1,   (a) -> 0);
        
        Arite1.InitOperations(elemNeutreAdd, identite);
        Arite2.InitOperations(soustraction, addition);
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        Observation x3 = new Observation();

        
        ///////////////////////////////////////////////IA2A
//        Parametre[] parametresA = new Parametre[14];
//        
//        for (int i = 0; i < parametresA.length; i++) {
//            parametresA[i] = new Parametre();
//        }
//        
//        Arite1 y1 = new Arite1(parametresA[0], x1);
//        Arite1 y2 = new Arite1(parametresA[1], x2);
//        Arite1 y3 = new Arite1(parametresA[2], x3);
//        
//        Arite2 z1 = new Arite2(parametresA[3], y1, y2);
//        Arite2 z2 = new Arite2(parametresA[4], y2, y3);
//        Arite2 z3 = new Arite2(parametresA[5], y1, y3);
//               
//        Arite1 w1 = new Arite1(parametresA[6], z1);
//        Arite1 w2 = new Arite1(parametresA[7], z2);
//        Arite1 w3 = new Arite1(parametresA[8], z3);
//        
//        Arite2 v1 = new Arite2(parametresA[9],  w1, w2);
//        Arite2 v2 = new Arite2(parametresA[10], w1, w3);
//        
//        Arite1 u1 = new Arite1(parametresA[11], v1);
//        Arite1 u2 = new Arite1(parametresA[12], v2);
//        
//        Arite2 rA = new Arite2(parametresA[13], u1, u2);

        ////////////////////////////////////////////////
        
        ///////////////////////////////////////////////IA2B
        Parametre[] parametresB = new Parametre[4];
        
        for (int i = 0; i < parametresB.length; i++) {
            parametresB[i] = new Parametre();
        }
        
        Arite1 a1 = new Arite1(parametresB[0], x1);
        Arite1 a2 = new Arite1(parametresB[1], x2);
        
        Arite2 b1 = new Arite2(parametresB[2], a1, a2);
        
        Arite1 rB = new Arite1(parametresB[3], b1);
        ///////////////////////////////////////////////
        
        float resultatAttendu = 0;
        
        ///////////////////////////////////////////////////
        //fenetres
        
        Integer score = 0;
        int scoreMax_2 = 0;
        int scoreMax_3 = 0;
        int scoreMax_4 = 0;
        int scoreMax_5 = 0;
        
        Fenetre fenIA1 = new Fenetre("IA1",score, Color.PINK);
        Fenetre fenIA3 = new Fenetre("IA3",score, Color.BLUE);
        Fenetre fenIAleatoire = new Fenetre("IAleatoire",score, Color.ORANGE);
        Fenetre fenIA2 = new Fenetre("IA2", score,Color.RED);
        FenetreScore fen_Score = new FenetreScore("Score IA2 et IA3");
        
        ////////////////////////////////////////////
        
        IA1 ia1 = new IA1(new int[]{5,5,1,1,1}, fenIA1.pan);
        
        
        long cpt = 0;

        while (true) {
           fenIA3.Update();
           fenIA2.Update();
           fenIAleatoire.Update();
           fenIA1.Update();
           fen_Score.Update();
           cpt++;
           
           
           
           
          
            /// AFFICHAGE DU SCORE
            
//            scoreMax_2 = fenIA2.pan.score;
//            scoreMax_3 = fenIA3.pan.score;
//            scoreMax_4 = fenIAleatoire.pan.score;
//            scoreMax_5 = fenIA1.pan.score;

            if(fenIA2.pan.score >= scoreMax_2){
                scoreMax_2 = fenIA2.pan.score;
            }
            
            if(fenIA3.pan.score >= scoreMax_3){
                scoreMax_3 = fenIA3.pan.score;
            }
            
            if(fenIAleatoire.pan.score >= scoreMax_4){
                scoreMax_4 = fenIAleatoire.pan.score;
            }
            if(fenIA1.pan.score >= scoreMax_5){
                scoreMax_5 = fenIA1.pan.score;
            }
            
            
           if (cpt%100 == 0){
               if (fen_Score.pan.listeScoreMax_2.size() > 200){
                   //fenIA2_Score.pan.listeScoreMax.remove(0);
                   int a = (int) (Math.random()*199)+1;
                   if (fen_Score.pan.listeScoreMax_2.get(a-1) == fen_Score.pan.listeScoreMax_2.get(a-1)) {
                   fen_Score.pan.listeScoreMax_2.remove(a);
                   }
                   if (fen_Score.pan.listeScoreMax_3.get(a-1) == fen_Score.pan.listeScoreMax_3.get(a-1)) {
                   fen_Score.pan.listeScoreMax_3.remove(a);
                   }
                   if (fen_Score.pan.listeScoreMax_4.get(a-1) == fen_Score.pan.listeScoreMax_4.get(a-1)) {
                   fen_Score.pan.listeScoreMax_4.remove(a);
                   }
                   if (fen_Score.pan.listeScoreMax_5.get(a-1) == fen_Score.pan.listeScoreMax_5.get(a-1)) {
                   fen_Score.pan.listeScoreMax_5.remove(a);
                   }
               }
                    
                   fen_Score.pan.listeScoreMax_2.add(scoreMax_2/10);
                   fen_Score.pan.listeScoreMax_3.add(scoreMax_3/10);
                   fen_Score.pan.listeScoreMax_4.add(scoreMax_4/10);
                   fen_Score.pan.listeScoreMax_5.add(scoreMax_5/10);
               
           }
           
           
           
           
          
           
           if (cpt%50 == 0) {
               
               
             
               //////////////////////////////////////////////////
               //IA3
               
                int width  = fenIA3.pan.getWidth()+1;
                int height = fenIA3.pan.getHeight()+1;

                observation[0] = (int) (fenIA3.pan.n.getX()*dimensionsObservation[0]/width);
                observation[1] = (int) (fenIA3.pan.b.getX()*dimensionsObservation[1]/width);
                observation[2] = (int) (fenIA3.pan.b.getY()*dimensionsObservation[2]/height);
                observation[3] = ((fenIA3.pan.n.getvX() < 0) ? 0 : 1);
                observation[4] = ((fenIA3.pan.n.getvY() < 0) ? 0 : 1);
                
                int[] actionPrecedente = new int[action.length];
                System.arraycopy(actionPrec[0], 0, actionPrecedente, 0, action.length);
                float certitude = (float)1.0;
                cerveau.IncrementerProbaConditionnelle(actionPrecedente, observationPrec, observation, certitude);
                
                cerveau.updateScoreQLearning(observationPrec, action, observation);
                
                action = cerveau.GetMeilleureActionParSituation(observation);//action = cerveau.GetMeilleureActionParSituationRec(observation, 0);

//                System.out.print(Arrays.toString(action));
//                System.out.println(cerveau.GetScoreParActionParSituation(action, observation));

                System.arraycopy(observation, 0, observationPrec, 0, observation.length);
                                
                
                
                
               System.arraycopy(action, 0, actionPrec[0], 0, action.length);
                
            }
                     
           
           float R = 300;
            switch (action[0]) {
                case 0:
                    fenIA3.pan.b.deplaceBarre(-1, fenIA3.pan);
                    resultatAttendu = -R;
                    break;
                case 1:
                    fenIA3.pan.b.deplaceBarre(1, fenIA3.pan);
                    resultatAttendu =  R;
                    break;
                case 2:
                    resultatAttendu = 0;
                    break;
                default:
                    break;
            }
            
            /////////////////////////////////////////////////
            //IA2
                
            
            if (cpt%50 == 0) {
                
                //Apprentissage
                
                x1.setValeur(fenIA3.pan.n.getX());
                x2.setValeur(fenIA3.pan.b.getX());
                x3.setValeur(fenIA3.pan.n.getY());

    //            rA.getValeur();
    //            for (Parametre parametre : parametresA) {
    //                parametre.update(resultatAttendu);
    //            }

                rB.getValeur();
                if (resultatAttendu == 0) resultatAttendu = rB.getValeur();

                for (Parametre parametre : parametresB) {
                    parametre.update(resultatAttendu);
                }
            }    
                
             
    
            
            //Action
            
            x1.setValeur(fenIA2.pan.n.getX());
            x2.setValeur(fenIA2.pan.b.getX());
            x3.setValeur(fenIA2.pan.n.getY());
            
            //float actionIA2A = rA.getValeur();
            float actionIA2B = rB.getValeur();
            
            //System.out.println("actA : " + actionIA2A);
            //System.out.println("actB : " + actionIA2B);
            
//            if (actionIA2A < - 5) {
//                actionIA2A = -1;
//            } else if (actionIA2A > 5) {
//                actionIA2A =  1;
//            }
            
            if (actionIA2B < - 1) {
                actionIA2B = -1;
            } else if (actionIA2B > 1) {
                actionIA2B =  1;
            }
            
            fenIA2.pan.b.deplaceBarre((int) actionIA2B, fenIA2.pan);
            
            /////////////////////////////////////////////////
            //IA1
                        
            ia1.updateScore();
            fenIA1.pan.b.deplaceBarre(ia1.output(new float[]{
                                                            fenIA1.pan.n.getX(),
                                                            fenIA1.pan.n.getY(),
                                                            fenIA1.pan.b.getX(),
                                                            }), fenIA1.pan);
            
            
            
            if (cpt%1000 == 0) {
                
                ia1.updateParams();
                
               // System.out.print("IA : ");
               // System.out.println(Arrays.toString(ia1.parametre));
            }
            
            
            /////////////////////////////////////////////////
            //IAléatoire
            
            if (cpt%10 == 0) {
                
            fenIAleatoire.pan.b.setX((int)(Math.random()*650) + 50);
            
            }
            
            
                     
        }        
    }    
}
