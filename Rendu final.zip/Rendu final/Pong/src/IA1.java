/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Baptiste
 */
public class IA1 {
    
    public int[] parametre, precedent, limites;
    public Panneau pan;
    public double score = 0, scorePrec = 0;

    public IA1(int[] limites, Panneau pan) {
        this.limites = limites;
        this.parametre = new int[limites.length];
        this.precedent = new int[limites.length];
//        this.parametre = new int[]{1, 3, 2, 0, 0};
        
        for (int i = 0; i < this.parametre.length; i++) {
            this.parametre[i] = (int)(Math.random()*(this.limites[i]+1));
            this.precedent[i] = this.parametre[i];
        }
        
        this.pan = pan;
    }
    
    public void updateScore() {
        score += 1.0/(2.0 + Math.abs(this.pan.b.getX() - this.pan.n.getX()));
       // score++;
        if (this.pan.b.getY() < this.pan.n.getY()) {
           score = 0;
        }
    }
    
    public void updateParams() {
        
       // System.out.println("Score : " + score + "   " + scorePrec + "   " + (score-scorePrec));
        
        if (this.score <= this.scorePrec) {
            System.arraycopy(this.precedent, 0, this.parametre, 0, this.parametre.length);
        }
        
        for (int i = 0; i < 2; i++) {
            int rando = (int)(Math.random()*this.parametre.length);
        
            this.parametre[rando] = (int) (Math.random()*(this.limites[rando] +1));

//            this.parametre[rando] = this.parametre[rando] > this.limites[rando] ? 0 : this.parametre[rando];
//            this.parametre[rando] = this.parametre[rando] < 0 ? this.limites[rando] : this.parametre[rando];
        }
               
        System.arraycopy(this.parametre, 0, this.precedent, 0, this.parametre.length);
        
        this.scorePrec = this.score;
        score = 0;
        
    }
    
    private float interpretation(float a , float b, int c) {
        switch (c) {
            case 0 : return a * b;
            case 1 : return a + b;
            case 2 : return a;
            case 3 : return b;
            case 4 : return a/b;
            case 5 : return b/a;
        }
        System.out.println("???????????????????????");
        System.out.println(c);
        return 0;
    }
    
    private float interpretation2(int b, float a) {
        switch (b) {
            case 0 : return  a;
            case 1 : return -a;
        }
        System.out.println("!!!!!!!!!!!!!!!!!!");
        return 0;
    }
    
    public int output(float[] inputs) {
        // y = A(X*x, B(Y*y, Z*z))
        
        double res = 
                 this.interpretation(
                this.interpretation2(this.parametre[2],inputs[0]), 
                this.interpretation(
                        this.interpretation2(this.parametre[3], inputs[1]), 
                        this.interpretation2(this.parametre[4], inputs[2]), 
                        this.parametre[1]),
                this.parametre[0]
                );
        return (res == 0 ? (Math.random() < 0.5 ? -1 : 1) : (res < 0 ? -1 : 1));
    }
                    
    
}
