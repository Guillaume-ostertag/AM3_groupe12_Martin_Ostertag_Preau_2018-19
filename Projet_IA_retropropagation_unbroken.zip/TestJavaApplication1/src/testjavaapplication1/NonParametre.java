/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public abstract class NonParametre extends Arbre {
    
    @Override
    float fctGradient() {
        float res;
        Arbre parentTmp = this.parent;
        if (parentTmp instanceof Arite1) {
            Arite1 A = (Arite1)parentTmp;
            float x = A.operande.getValeur();
            float a = A.parametre.getValeur();
            res = a*A.d_fct1(x) + (1-a)*A.d_fct2(x);
        } else if (parentTmp instanceof Arite2) {
            Arite2 A = (Arite2)parentTmp;
            float a = A.parametre.getValeur();
            if (A.estOperande1(this)) {
                float x = A.operande1.getValeur();
                res = a*A.d_fct1_dx1(x) + (1-a)*A.d_fct2_dx1(x);
            } else if (A.estOperande2(this)) {
                float x = A.operande2.getValeur();
                res = a*A.d_fct1_dx2(x) + (1-a)*A.d_fct2_dx2(x);
            } else {
                System.out.println("erreur!!!! ni op1 ni op2! (gradient : non parmetre)");
                res = 420;
            }
        } else {
            System.out.println("?????? (parametre fct gradient)");
            res = 420;
        }
        return res;
    }
    
    public NonParametre() {
        super();
    }
    
}
