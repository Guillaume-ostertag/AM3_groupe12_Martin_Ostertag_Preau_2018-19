/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Arite2 extends Operation {
    protected NonParametre operande1;
    protected NonParametre operande2;
    
    public Arite2(Parametre parametre, NonParametre operande1, NonParametre operande2) {
        super(parametre);
        this.operande1 = operande1;
        this.operande1.setParent(this);
        this.operande2 = operande2;
        this.operande2.setParent(this);
    }
    
    protected float fct1(float x1, float x2) {
        return x1*x2;
    }
    
    protected float d_fct1_dx1(float x1) {
        return this.operande2.getValeur();
    }
    protected float d_fct1_dx2(float x2) {
        return this.operande1.getValeur();
    }
    
    protected float fct2(float x1, float x2) {
        return x1+x2;
    }
    
    protected float d_fct2_dx1(float x1) {
        return 1;
    }
    protected float d_fct2_dx2(float x2) {
        return 1;
    }

    protected boolean estOperande1(Arbre A) {
        return A == this.operande1;
    }
    
    protected boolean estOperande2(Arbre A) {
        return A == this.operande2;
    }
    
    @Override
    public float getValeur() {
        if (this.valeurCalclulee) {
            return this.valeur;
        }
        else {
            float a = this.parametre.getValeur();
            float x = this.operande1.getValeur();
            float y = this.operande2.getValeur();
            this.valeur = a*fct1(x, y) + (1 - a)*fct2(x, y);
            //this.valeurCalclulee = true;
            return this.valeur;
        }
    }
    
}
