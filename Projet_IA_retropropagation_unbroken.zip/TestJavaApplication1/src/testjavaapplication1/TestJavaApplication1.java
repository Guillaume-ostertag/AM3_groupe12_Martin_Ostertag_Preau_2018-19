/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class TestJavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        
        Parametre p1 = new Parametre();
        Parametre p2 = new Parametre();
        Parametre p3 = new Parametre();
        Parametre p4 = new Parametre();

        Arite1 a1_1 = new Arite1(p1, x1);
        Arite1 a1_2 = new Arite1(p2, x2);
        
        Arite2 a2_1 = new Arite2(p3, a1_1, a1_2);
        
        Arite1 y = new Arite1(p4, a2_1);
        
        float erreur_moyenne = (float)0.0;
        float erreur;
        
        int i;
        for (i = 0 ; i < 300 ; i++) {
            
            x1.setValeur((float)(Math.random()-0.5)*200);
            x2.setValeur((float)(Math.random()-0.5)*200);
            
            float resultatAttendu = 1/(1/x1.getValeur() * 1/x2.getValeur());
            
            float qlqch = y.getValeur();
            
            p1.update(resultatAttendu);
            p2.update(resultatAttendu);
            p3.update(resultatAttendu);
            p4.update(resultatAttendu);
            
            erreur = Math.abs(resultatAttendu - y.getValeur());
            erreur_moyenne += erreur;
            
            System.out.println("erreur : " + erreur);
                
        }
        erreur_moyenne = erreur_moyenne/i;
        System.out.println("moyenne : " + erreur_moyenne);
        System.out.println("p1 : " + p1.getValeur());
        System.out.println("p2 : " + p2.getValeur());
        System.out.println("p3 : " + p3.getValeur());
        System.out.println("p4 : " + p4.getValeur());
    }
    
}
