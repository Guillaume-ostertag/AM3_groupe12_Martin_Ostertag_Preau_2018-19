/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testsituations;

/**
 *
 * @author garr
 */
public class Compteur {
    private static int I = 0;

    public Compteur() {
    }
    
    public static void inc() {
        Compteur.I++;
    }
    
    public static void raz() {
        Compteur.I = 0;
    }
    
    public static void sout() {
        System.out.println(Compteur.I);
    }
    
}
