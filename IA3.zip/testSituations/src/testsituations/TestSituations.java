/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testsituations;

import java.util.Arrays;

/**
 *
 * @author garr
 */

import java.awt.Container;
import java.awt.Graphics2D;

public class TestSituations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Situations s = new IA(1, 3);
        Compteur.sout();
        int tab[] = {3,2,4};
        
        TableauNEntrees t = new TableauNEntrees(tab);
        Compteur.sout();
        t.SetValeurs(12);
        t.Affiche();
        int tab2[] = {0,1,0};
        t.SetValeursParDimension(tab2, 42);
        t.Affiche(tab2);
        System.out.println("");
        t.Affiche();
        System.out.println("");
        int tab3[] = {1,0};
        t.SetValeursParDimension(tab3, 34);
        t.Affiche();
        System.out.println("");
        t.Affiche(tab3);
        
        System.out.println(t.GetValeur(tab2));
        System.out.println(t.GetNombreElements());
        System.out.println(t.GetNombreElements(2));
        System.out.println(t.GetNombreElements(2, 1));
        System.out.println("");
        System.out.println("////////////");
        System.out.println("");
        Compteur.raz();
        
        int observations[] = {3,3,3,2,2};
        int actions[] = {3};

        IA s = new IA(actions, observations);
        
//        Compteur.sout();
//        int actions1[] = {0,1};
//        int situation1[] = {0,0};
//        int situation2[] = {2,1};
//        System.out.println(s.GetValeursParDimension(actions1, situation1, situation2));
//        for (int i = 0 ; i < 1 ; i++) {
//            s.IncrementerProbaConditionnelle(actions1, situation1, situation2, (float)0.1);
//            s.AfficherProbas(actions1, situation1);
//        }
//
//        s.AfficherScores();
//        System.out.println("////");
//        s.SetScore(situation2, 5);
//        s.AfficherScores();
//        System.out.println("score de l'action : ");
//        System.out.println(s.GetScoreParActionParSituation(actions1, situation1));
//        
//        int actions2[] = s.GetMeilleureActionParSituation(situation1);
//        System.out.println(Arrays.toString(actions2));
//        int actions3[] = {1,0};
//        System.out.println(s.GetScoreParActionParSituation(actions3, situation1));
        
        System.out.println("");
        System.out.println("=============================");
        System.out.println("");
        int actionsI[] = new int[actions.length];
        int actionsI1[] = new int[actions.length];
        int actionsI2[] = new int[actions.length];
        int[] situationI1 = new int[observations.length];
        int[] situationI2 = new int[observations.length];
        
        for (int i = 0; i < 2000; i++) {
            for (int j = 0; j < situationI1.length; j++) {
                situationI1[j] = (int)Math.floor(Math.random()*observations[j]);
            }
            int rando = (int)Math.round((Math.random()-0.5)*2)*10;
            s.SetScore(situationI1, rando);
        }
        
        s.AfficherScores();
        
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < actionsI.length; j++) {
                actionsI[j] = (int)Math.floor(Math.random()*actions[j]);
            }
            for (int j = 0; j < situationI1.length; j++) {
                situationI1[j] = (int)Math.floor(Math.random()*observations[j]);
                situationI2[j] = (int)Math.floor(Math.random()*observations[j]);
            }
            s.IncrementerProbaConditionnelle(actionsI, situationI1, situationI2, (float)0.1);
        }
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < situationI1.length; j++) {
                situationI1[j] = (int)Math.floor(Math.random()*observations[j]);
            }
            actionsI1 = s.GetMeilleureActionParSituation(situationI1);
            actionsI2 = s.GetMeilleureActionParSituationRec(situationI1, 2);
            System.out.print("Meilleure action selon situation " + Arrays.toString(situationI1) + " : ");
            System.out.print(Arrays.toString(actionsI1) + " ");
            System.out.println("avec un score de : " + s.GetScoreParActionParSituation(actionsI1, situationI1));
            
            System.out.print("Meilleure action selon situation " + Arrays.toString(situationI1) + " : ");
            System.out.print(Arrays.toString(actionsI2) + " ");
            System.out.println("avec un score de : " + s.GetScoreParActionParSituation(actionsI2, situationI1));
            System.out.println("");
        }
                
        System.out.println("fin");
        
        
    }
    
}
