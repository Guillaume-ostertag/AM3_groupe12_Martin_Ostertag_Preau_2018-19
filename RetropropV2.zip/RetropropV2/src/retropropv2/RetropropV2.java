/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public class RetropropV2 {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        
        FonctionArite2 addition       = new FonctionArite2((a, b) -> a+b, (a, b) -> 1, (a, b) -> 1);
        FonctionArite2 multiplication = new FonctionArite2((a, b) -> a*b, (a, b) -> b, (a, b) -> a);
        FonctionArite2 minimum        = new FonctionArite2((a, b) -> Math.min(a, b), (float a, float b) -> a < b ? 1 : 0, (a, b) -> a < b ? 0 : 1);
        
        FonctionArite1 sinus    = new FonctionArite1((a) -> (float)Math.sin(a), (a) -> (float)Math.cos(a));
        FonctionArite1 inverse  = new FonctionArite1((a) -> 1/a, (a) -> -1/(a*a));
        FonctionArite1 negatif  = new FonctionArite1((a) -> -a,  (a) -> -1); //somehow brocken??
        FonctionArite1 carre    = new FonctionArite1((a) -> a*a, (a) -> 2*a);
        FonctionArite1 identite = new FonctionArite1((a) -> a,   (a) -> 1);
        
        FonctionArite2[] FA2 = {addition, multiplication};
        FonctionArite1[] FA1 = {sinus, identite}; 
        
        Arite2.InitOperations(FA2);
        Arite1.InitOperations(FA1);
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        //Observation x3 = new Observation();
        
        Parametre[] p1 = new Parametre[FA1.length];
        Parametre[] p2 = new Parametre[FA1.length];
        //Parametre[] p3 = new Parametre[FA1.length];
        
        for (int i = 0; i < FA1.length; i++) {
            p1[i] = new Parametre();
            p2[i] = new Parametre();
            //p3[i] = new Parametre();
        }
        
        Parametre[] p4 = new Parametre[FA2.length];
        
        for (int i = 0; i < FA2.length; i++) {
            p4[i] = new Parametre();
        }
        System.out.println("?");
        Arite1 y1 = new Arite1(p1, x1);
        System.out.println("-");
        Arite1 y2 = new Arite1(p2, x2);
        System.out.println("--");
        //Arite1 y3 = new Arite1(p3, x3);
        System.out.println("??");
        Arite2 z = new Arite2(p4, y1, y2);
        System.out.println("???");
        float erreur_moyenne = 0;
        float[] tabErreurs = new float[50];
        for (int j = 0; j < tabErreurs.length-1 ; j++) {
            tabErreurs[j] = 99999;
        }
        float moyenneDernieresErreurs;
        float erreur;
        
        int i;
        for (i = 0 ; i < 50000 ; i++) {
            
            x1.setValeur((float)(Math.random()-0.5)*1000);
            x2.setValeur((float)(Math.random()-0.5)*1000);
            //x3.setValeur((float)(Math.random()-0.5)*1000);
            
            float resultatAttendu = x1.getValeur() + x2.getValeur();
            
            float qlqch = z.getValeur();
                                    
            erreur = Math.abs(resultatAttendu - qlqch);
            erreur_moyenne += erreur;
            
            moyenneDernieresErreurs = erreur;
            tabErreurs[tabErreurs.length-1] = erreur;
            
            for (int j = 0; j < tabErreurs.length-1 ; j++) {
                moyenneDernieresErreurs += tabErreurs[j];
                tabErreurs[j] = tabErreurs[j+1];
            }
            
            moyenneDernieresErreurs /= tabErreurs.length;
            
            //System.out.println("erreur : " + erreur);
            //System.out.println("moyenneDernieresErreurs : " + moyenneDernieresErreurs);
            
            if (moyenneDernieresErreurs == 0) {
                System.out.println("nombre de tours d'entrainement : " + i);
                break;
            }
            
            for (int j = 0; j < FA1.length; j++) {
                p1[j].update(resultatAttendu);
                p2[j].update(resultatAttendu);
            }
            for (int j = 0; j < FA2.length; j++) {
                p4[j].update(resultatAttendu);
            }
            
            for (int j = 0; j < FA1.length; j++) {
                p1[j].normalize();
                p2[j].normalize();
            }
            for (int j = 0; j < FA2.length; j++) {
                p4[j].normalize();
            }
            //System.out.println("_________________________________");               
        }
        erreur_moyenne = erreur_moyenne/i;
        System.out.println("moyenne : " + erreur_moyenne);

        for (int j = 0; j < FA1.length; j++) {
            System.out.println(p1[j].getValeur());
        }
        System.out.println("");
        for (int j = 0; j < FA1.length; j++) {
            System.out.println(p2[j].getValeur());
        }
        System.out.println("");
        for (int j = 0; j < FA2.length; j++) {
            System.out.println(p4[j].getValeur());
        }
        
        for (i = 0 ; i < 10 ; i++) {
            
            x1.setValeur((float)(Math.random()-0.5)*1000);
            x2.setValeur((float)(Math.random()-0.5)*1000);
            //x3.setValeur((float)(Math.random()-0.5)*1000);
            
            float resultatAttendu = x1.getValeur() + x2.getValeur();
            
            float qlqch = z.getValeur();
            
            erreur = Math.abs(resultatAttendu - z.getValeur());

            System.out.println("");
            System.out.println("resultat donné   : " + qlqch);
            System.out.println("resultat attendu : " + resultatAttendu);
            System.out.println("erreur           : " + erreur);
        }    
    }    
}
