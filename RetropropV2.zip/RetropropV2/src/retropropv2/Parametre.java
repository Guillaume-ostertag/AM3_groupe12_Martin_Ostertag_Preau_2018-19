
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public class Parametre extends Arbre {
    
    protected float valeurNonNormalisee;

    public Parametre() {
        super();
        this.valeur = (float)Math.random();
        //this.valeur = (float)(1/2.0);
        this.valeurCalclulee = true;
    }
    
    @Override
    float fctGradient() {
        if (this.parent instanceof Arite1) {
            Arite1 A = (Arite1)this.parent;
            float x = A.operande.getValeur();
            return Arite1.operations[A.quelParametre(this)].f.eval(x);
        } else if (this.parent instanceof Arite2) {
            Arite2 A = (Arite2)this.parent;
            float x1 = A.operande1.getValeur();
            float x2 = A.operande2.getValeur();
            return Arite2.operations[A.quelParametre(this)].f.eval(x1, x2);
        } else {
            System.out.println("?????? (parametre fct gradient)");
            return 420;
        }
    }

    @Override
    public float getValeur() {
        return this.valeur;
    }
    
    public void update(float resultatAttendu) {
        this.gradient = this.calculGradient(resultatAttendu);
        this.resetValeur();
        
        //this.gradient = (float) (2*(1/(1 + Math.pow(Math.E, -this.gradient/10))-0.5));
        //this.gradient = (float) ((1/(1 + Math.pow(Math.E, -this.gradient/10))-0.5));
  
        this.valeur += this.gradient;
        //System.out.println(this.gradient);
       
        //this.valeurTmp = (this.valeurTmp*100)/div;
        if (this.valeur < 0.001) this.valeur = (float)0.001;
        else if (this.valeur > 100) this.valeur = 100;
        
        this.valeurNonNormalisee = this.valeur;
        
        this.valeurCalclulee = true;
    }

    public void normalize() {
        Operation A = (Operation)this.parent;
        float div = 0;
        for (int i = 0; i < A.parametres.length; i++) {
            div += A.parametres[i].valeurNonNormalisee;
        }
        this.valeur = this.valeur*100 / div;
    }
    
}
