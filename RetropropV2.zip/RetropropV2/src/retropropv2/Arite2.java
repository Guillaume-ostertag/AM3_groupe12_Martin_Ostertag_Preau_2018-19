/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public class Arite2 extends Operation {
    
    protected NonParametre operande1;
    protected NonParametre operande2;
    static protected FonctionArite2[] operations;
    
    static public void InitOperations(FonctionArite2[] op) {
        Arite2.operations = new FonctionArite2[op.length];
        System.arraycopy(op, 0, Arite2.operations, 0, op.length);
    }
    
    public Arite2(Parametre[] parametres, NonParametre operande1, NonParametre operande2) {
        super(parametres);
        this.operande1 = operande1;
        this.operande1.setParent(this);
        this.operande2 = operande2;
        this.operande2.setParent(this);
    }

    protected boolean estOperande1(Arbre A) {
        return A == this.operande1;
    }
    
    protected boolean estOperande2(Arbre A) {
        return A == this.operande2;
    }
        
    @Override
    public float getValeur() {
        if (this.valeurCalclulee) {
            return this.valeur;
        }
        else {
            float x1 = this.operande1.getValeur();
            float x2 = this.operande2.getValeur();
            float res = 0;
            float div = 0;
            for (int i = 0; i < this.parametres.length; i++) {
                res += this.parametres[i].getValeur()*Arite2.operations[i].f.eval(x1, x2);
                div += this.parametres[i].getValeur();
            }
            this.valeur = res / div;
            return this.valeur;
        }
    }    
}
