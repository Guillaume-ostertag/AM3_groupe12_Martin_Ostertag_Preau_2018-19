/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public abstract class Operation extends NonParametre {
    
    protected Parametre[] parametres;
        
    public Operation(Parametre[] parametres) {
        super();
        this.parametres = new Parametre[parametres.length];
        for (int i = 0 ; i < parametres.length ; i++) {
            this.parametres[i] = parametres[i];
            this.parametres[i].setParent(this);
        }
    }
    
    protected int quelParametre(Arbre A) {
        for (int i = 0 ; i < this.parametres.length ; i++) {
            if (A == this.parametres[i]) {
                return i;
            }
        }
        System.out.println("pas un parametre!!");
        return 0;
    }
}
