/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public class Arite1 extends Operation {
    
    protected NonParametre operande;
    static protected FonctionArite1[] operations;
    
    static public void InitOperations(FonctionArite1[] op) {
        Arite1.operations = new FonctionArite1[op.length];
        System.arraycopy(op, 0, Arite1.operations, 0, op.length);
    }
    
    public Arite1(Parametre[] parametres, NonParametre operande) {
        super(parametres);
        this.operande = operande;
        this.operande.setParent(this);
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) return this.valeur;
        else {
            float x = this.operande.getValeur();
            float res = 0;
            float div = 0;
            for (int i = 0; i < this.parametres.length; i++) {
                res += this.parametres[i].getValeur()*Arite1.operations[i].f.eval(x);
                div += this.parametres[i].getValeur();
            }
            this.valeur = res / div;
            return this.valeur;
        }
    }  
}
