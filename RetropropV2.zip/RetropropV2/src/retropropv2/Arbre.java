/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public abstract class Arbre {
    protected float valeur;
    protected float gradient;
    protected Arbre parent;
    protected boolean valeurCalclulee;
    private boolean gradientCalcule;

    public Arbre() {
        this.valeurCalclulee = false;
        this.gradientCalcule = false;
    }
    
    abstract public float getValeur();

    protected void setParent(Arbre parent) {
        this.parent = parent;
    }
    
    abstract  float fctGradient();
        
    protected float calculGradient(float resultatAttendu) {
        if (this.gradientCalcule) {
            return this.gradient;
        } else {
            if (this.parent == null) this.gradient = 2*(resultatAttendu - this.valeur);
            else this.gradient = this.fctGradient() * this.parent.calculGradient(resultatAttendu);
            //this.gradient = (float) (2*(1/(1 + Math.pow(Math.E, -this.gradient))-0.5));
            //this.gradientCalcule = true;
            //System.out.println("grad : " + this.gradient);
            if (Float.isNaN(this.gradient)) {
                System.out.println("IS NAN!!");
                this.gradient = 0;
            }
            return this.gradient;
        }
    }
    
    protected void resetValeur() {
        this.valeurCalclulee = false;
        this.gradientCalcule = false;
        if (this.parent != null) this.parent.resetValeur();
    }
       
}