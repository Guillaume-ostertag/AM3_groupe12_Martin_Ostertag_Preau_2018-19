/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retropropv2;

/**
 *
 * @author garr
 */
public abstract class NonParametre extends Arbre {
    
    @Override
    float fctGradient() {
        float res = 0;
        float div = 0;
        Arbre parentTmp = this.parent;
        if (parentTmp instanceof Arite1) {
            Arite1 A = (Arite1)parentTmp;
            float x = A.operande.getValeur();
            for (int i = 0; i < A.parametres.length; i++) {
                res += A.parametres[i].getValeur()*Arite1.operations[i].df.eval(x);
                div += A.parametres[i].getValeur();
            }
            res /= div;
        } else if (parentTmp instanceof Arite2) {
            Arite2 A = (Arite2)parentTmp;
            float x1 = A.operande1.getValeur();
            float x2 = A.operande2.getValeur();
            if (A.estOperande1(this)) {
                for (int i = 0; i < A.parametres.length; i++) {
                    res += A.parametres[i].getValeur()*Arite2.operations[i].df1.eval(x1, x2);
                    div += A.parametres[i].getValeur();
                }
                res /= div;
            } else if (A.estOperande2(this)) {
                for (int i = 0; i < A.parametres.length; i++) {
                    res += A.parametres[i].getValeur()*Arite2.operations[i].df2.eval(x1, x2);
                    div += A.parametres[i].getValeur();
                }
                res /= div;
            } else {
                System.out.println("erreur!!!! ni op1 ni op2! (gradient : non parmetre)");
                res = 420;
            }
        } else {
            System.out.println("?????? (parametre fct gradient)");
            res = 420;
        }
        return res;
    }
    
    public NonParametre() {
        super();
    }
    
}
