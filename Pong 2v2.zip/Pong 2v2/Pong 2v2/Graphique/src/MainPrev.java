
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class MainPrev {
    public static void main (String[] args){
        
        int cpt = 0;
        
        int[] observation = {3,2,2,2};
        int[] action = {3};
        IA cerveau = new IA(action, observation);
        int [] observationPrec = new int [observation.length];
        
        int A = 20;
        int [][] actionPrec = new int [A][action.length];
        for (int i = 0; i < A; i++) {
            for (int j = 0; j < action.length; j++) {
                actionPrec[i][j] = 0;
            }
        }
        
        int balleXprec = 0;
        int balleYprec = 0;
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 2; k++) {
                    for (int l = 0; l < 2; l++) {
                        int[] tab = {i, j, k, l};
                        if      (j == 1) cerveau.SetScore(tab, -10);
                        else if (i == 2) cerveau.SetScore(tab,  30);
                    }
                }
            }
        }
        
        Fenetre fen = new Fenetre("fentreJava");
       // fen.moveRect();
//        fen.repaint();
        while (true) {
           fen.Update();
           cpt++;
           if (cpt > 30) {
               cpt = 0;
                int w = fen.pan.getWidth()+1;

                 //System.out.println(w);

                observation[0] = ((fen.pan.n.getX() < fen.pan.b1.getX()) ? 0 : ((fen.pan.n.getX() > fen.pan.b1.getX()+fen.pan.b1.getSize()) ? 1 : 2));
                observation[1] = ((fen.pan.n.getY() < fen.pan.b1.getY()) ? 0 : 1);
                observation[2] = ((balleXprec < fen.pan.n.getX()) ? 0 : 1);
                observation[3] = ((balleYprec < fen.pan.n.getY()) ? 0 : 1);
                
                //int[] actionPrecedente = new int[action.length];
                //System.arraycopy(actionPrec[9], 0, actionPrecedente, 0, action.length);
                //cerveau.IncrementerProbaConditionnelle(actionPrecedente, observationPrec, observation, (float)0.8);

                for (int i = 0; i < A; i++) {
                    int[] actionPrecedente = new int[action.length];
                    System.arraycopy(actionPrec[i], 0, actionPrecedente, 0, action.length);
                    //float certitude = (i-1)/10;
                    float certitude = (float)0.1*(i/2);
                    //float certitude = (float)0.5;
                    cerveau.IncrementerProbaConditionnelle(actionPrecedente, observationPrec, observation, certitude);
                }
                
                cerveau.updateScoreQLearning(observationPrec, action, observation);
                
                action = cerveau.GetMeilleureActionParSituation(observation);
                //action = cerveau.GetMeilleureActionParSituationRec(observation, 0);

                System.out.print(Arrays.toString(action));
                System.out.println(cerveau.GetScoreParActionParSituation(action, observation));

                System.arraycopy(observation, 0, observationPrec, 0, observation.length);
                                
                for (int i = 0; i < A-1; i++) {
                   System.arraycopy(actionPrec[i+1], 0, actionPrec[i], 0, action.length);
                }
                
               System.arraycopy(action, 0, actionPrec[A-1], 0, action.length);
                
                balleXprec = (int) fen.pan.n.getX();
                balleYprec = (int) fen.pan.n.getY();

             }
           
            switch (action[0]) {
                case 0:
                    fen.pan.b1.deplaceBarre(-1, fen.pan);
                    break;
                case 1:
                    fen.pan.b1.deplaceBarre(1, fen.pan);
                    break;
                case 2:
                    break;
                default:
                    break;
            }
           
        }
    }
}
