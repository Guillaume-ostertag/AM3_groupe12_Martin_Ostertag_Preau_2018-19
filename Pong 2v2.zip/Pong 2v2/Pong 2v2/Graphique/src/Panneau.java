/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
 
public class Panneau extends JPanel { 
  public Barre b1 = new Barre(350/2, 650,200,10,Color.BLACK,"RECT");
  public Barre b2 = new Barre(350/2, 30,200,10,Color.BLACK,"RECT");
  public Balle n = new Balle(20, 350, 100,(float)0.000, (float)0.7, (float)1);
  
  
  private boolean click = false;
  private boolean barreDroite;
  
  public Panneau (){
      this.addMouseListener(new MouseAdapter(){
      @Override
      public void mousePressed(MouseEvent e){
          click = true;
          if (SwingUtilities.isLeftMouseButton(e)) barreDroite = false;
          else barreDroite = true;
      }
      @Override
      public void mouseReleased(MouseEvent e){
          click = false;
      }
    });
      
      
  }
  
  public boolean estClick(){
      return click;
  }
  
  @Override
  public void paintComponent(Graphics g){
      g.setColor(Color.WHITE);
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
      g.setColor(Color.BLACK);
    
    g.fillRect(b1.getX()-b1.getSize()/2, b1.getY(), b1.getSize(), b1.getHeight());
    g.fillRect(b2.getX()-b2.getSize()/2, b2.getY(), b2.getSize(), b2.getHeight());
    g.fillOval((int)n.getX(), (int)n.getY(), n.getSize(), n.getSize());
    
  }      
  
  public void update(){
      
      n.deplacement(this);
      
      if(this.click == true)
        if(this.barreDroite) b1.deplaceBarre(5, this);
        else b1.deplaceBarre(-5, this);
      
    if (n.getX() > b1.getX() - b1.getSize()/2 &&
        n.getX() < b1.getX() + b1.getSize()/2 &&
        //n.getY() > b1.getY() &&
        n.getY() == b1.getY() - b1.getHeight()) {
        
       
        n.setvY(n.getvY()*-1);
        
        if(this.barreDroite) {
            n.addvX(3*(float)0.1);
        }
        
        else n.addvX(-3*(float)0.1);
        
    }
    
    else if (n.getX() > b2.getX() - b2.getSize()/2 &&       // bug surement ici
        n.getX() < b2.getX() + b2.getSize()/2 &&
        n.getY() > b2.getY() &&
        n.getY() < b2.getY() + b2.getHeight()) {
        
       
        n.setvY(n.getvY()*-1);
        
        if(this.barreDroite) {
            n.addvX(3*(float)0.1);
        }
        
        else n.addvX(-3*(float)0.1);
        
    }
    
    
    
    if (n.getY() > b1.getY()+20 || n.getY() < b2.getY() -20){
        n.setY(350);
        float signe = Math.signum(n.getY());
        n.setvY(-n.getvY());
        n.setvX((float)0.7);
        n.invertvX();
    }
  }
}
