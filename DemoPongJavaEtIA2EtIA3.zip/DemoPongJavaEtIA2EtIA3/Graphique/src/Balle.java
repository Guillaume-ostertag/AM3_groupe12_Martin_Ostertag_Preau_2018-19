/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class Balle {
    private int size;
    private float x;
    private float y;
    private float a;
    private float vX;
    private float vY;

    public int getSize() {
        return size;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getA() {
        return a;
    }

    public float getvX() {
        return vX;
    }

    public float getvY() {
        return vY;
    }
    
     public void setvY(float vY) {
        this.vY = vY;
    }
    
     public Balle() {
        this.size = 10;
        this.x = 100+(float)(Math.random()*1000);
        this.y = 100;
        this.a = (float)0.05;
        this.vX = (float)(Math.random()-0.5);
        this.vY = 0;
    }

    public Balle(int size, int x, int y, float a, float vX, float vY) {
        this.size = size;
        this.x = x;
        this.y = y;
        this.a = a;
        this.vX = vX;
        this.vY = vY;
    }
    
    public void deplacement(Panneau p){
        

//        if ((int)(Math.random()*7000) == 0) {
//            this.x = 30 + (float) (Math.random()*(p.getWidth() - 30 ));
//            this.y = 50;
//            this.vY = 0;
//            this.vX = (float)0.5 * (Math.random() < 0.5 ? -1 : 1);
//        }
        
        if (x >= p.getWidth()  || x <= 0) this.vX *= -1;
        if (y >= p.getHeight() || y <= 0) this.vY *= -1;
        
//        if (x >= p.getWidth()-10) this.x = 20;
//        if (x <= 10) this.x = p.getWidth()-20;
        
        this.vY += this.a ;
        
        this.x  += this.vX;
        this.y  += this.vY;
           
        
    }


}
