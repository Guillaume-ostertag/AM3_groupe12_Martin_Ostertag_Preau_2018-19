
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class Fenetre extends JFrame{
    public Panneau pan;
    public Fenetre(String s){
        this.setTitle(s);
        this.setSize(800, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
        this.setVisible(true);
        this.setResizable(false);
        
        pan = new Panneau();
        this.setContentPane(pan);

    }
    
    public void Update(){
            pan.update();
            pan.repaint();
            try {
                Thread.sleep(0,1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    
}

