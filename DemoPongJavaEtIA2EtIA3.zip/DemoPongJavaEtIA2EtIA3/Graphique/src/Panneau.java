/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
 
public class Panneau extends JPanel { 
  public Barre b = new Barre(100, 3*400/4,200,10,Color.BLACK,"RECT");
  public Balle n = new Balle(10, 100, 100,(float)0.002, (float)0.5, 0);
  
  private boolean click = false;
  private boolean barreDroite;
  
  public Panneau (){
      this.addMouseListener(new MouseAdapter(){
      @Override
      public void mousePressed(MouseEvent e){
          click = true;
          if (SwingUtilities.isLeftMouseButton(e)) barreDroite = false;
          else barreDroite = true;
      }
      @Override
      public void mouseReleased(MouseEvent e){
          click = false;
      }
    });
      
      
  }
  @Override
  public void paintComponent(Graphics g){
      g.setColor(Color.WHITE);
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
      g.setColor(Color.BLACK);
    
    g.fillRect(b.getX()-b.getSize()/2, b.getY(), b.getSize(), b.getHeight());
    g.fillOval((int)n.getX(), (int)n.getY(), n.getSize(), n.getSize());
    
  }      
  
  public void update(){
      
      n.deplacement(this);
      
      if(this.click == true)
        if(this.barreDroite) b.deplaceBarre(5, this);
        else b.deplaceBarre(-5, this);
      
    if (n.getX() > b.getX() - b.getSize()/2 &&
        n.getX() < b.getX() + b.getSize()/2 &&
        n.getY() > b.getY() &&
        n.getY() < b.getY() + b.getHeight()) {
        
        n.setvY(n.getvY()*-1);
    }
  }
}
