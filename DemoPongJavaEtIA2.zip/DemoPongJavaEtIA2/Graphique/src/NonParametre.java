/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public abstract class NonParametre extends Arbre {
    
    @Override
    float fctGradient() {
        float res;
        Arbre parentTmp = this.parent;
        if (parentTmp instanceof Arite1) {
            Arite1 A = (Arite1)parentTmp;
            float x = A.operande.getValeur();
            float a = A.parametre.getValeur();
            res = (a*Arite1.op1.df.eval(x) + (Arbre.range-a)*Arite1.op2.df.eval(x))/Arbre.range;
        } else if (parentTmp instanceof Arite2) {
            Arite2 A = (Arite2)parentTmp;
            float a = A.parametre.getValeur();
            float x1 = A.operande1.getValeur();
            float x2 = A.operande2.getValeur();
            if (A.estOperande1(this)) {
                res = (a*Arite2.op1.df1.eval(x1, x2) + (Arbre.range-a)*Arite2.op2.df1.eval(x1, x2))/Arbre.range;
            } else if (A.estOperande2(this)) {
                res = (a*Arite2.op1.df2.eval(x1, x2) + (Arbre.range-a)*Arite2.op2.df2.eval(x1, x2))/Arbre.range;
            } else {
                System.out.println("erreur!!!! ni op1 ni op2! (gradient : non parmetre)");
                res = 420;
            }
        } else {
            System.out.println("?????? (parametre fct gradient)");
            res = 420;
        }
        return res;
    }
    
    public NonParametre() {
        super();
    }
    
}
