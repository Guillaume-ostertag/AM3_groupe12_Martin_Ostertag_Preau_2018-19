
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class Main {
    public static void main (String[] args){
               
        
        ////////////////////////////////////////////////////
        //IA2
        
        
        FonctionArite2 addition       = new FonctionArite2((a, b) -> a+b, (a, b) ->  1, (a, b) ->  1);
        FonctionArite2 soustraction   = new FonctionArite2((a, b) -> a-b, (a, b) -> -1, (a, b) -> -1);
        FonctionArite2 multiplication = new FonctionArite2((a, b) -> a*b, (a, b) ->  b, (a, b) ->  a);
        FonctionArite2 minimum        = new FonctionArite2((a, b) -> Math.min(a, b), (float a, float b) -> a < b ? 1 : b, (a, b) -> a < b ? a : 1);
        
        FonctionArite1 sinus    = new FonctionArite1((a) -> (float)Math.sin(a), (a) -> (float)Math.cos(a));
        FonctionArite1 inverse  = new FonctionArite1((a) -> 1/a, (a) -> -1/(a*a));
        FonctionArite1 negatif  = new FonctionArite1((a) -> -a,  (a) -> -1); //somehow brocken??
        FonctionArite1 carre    = new FonctionArite1((a) -> a*a, (a) -> 2*a);
        FonctionArite1 identite = new FonctionArite1((a) -> a,   (a) -> 1);
        FonctionArite1 elemNeutreAdd  = new FonctionArite1((a) -> 0,   (a) -> 0);
        FonctionArite1 elemNeutreMult = new FonctionArite1((a) -> 1,   (a) -> 0);
        
        Arite1.InitOperations(elemNeutreAdd, identite);
        Arite2.InitOperations(soustraction, addition);
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        Observation x3 = new Observation();

        Parametre[] parametres = new Parametre[14];
        
        for (int i = 0; i < parametres.length; i++) {
            parametres[i] = new Parametre();
        }
        
        Arite1 y1 = new Arite1(parametres[0], x1);
        Arite1 y2 = new Arite1(parametres[1], x2);
        Arite1 y3 = new Arite1(parametres[2], x3);
        
        Arite2 z1 = new Arite2(parametres[3], y1, y2);
        Arite2 z2 = new Arite2(parametres[4], y2, y3);
        Arite2 z3 = new Arite2(parametres[5], y1, y3);
               
        Arite1 w1 = new Arite1(parametres[6], z1);
        Arite1 w2 = new Arite1(parametres[7], z2);
        Arite1 w3 = new Arite1(parametres[8], z3);
        
        Arite2 v1 = new Arite2(parametres[9],  w1, w2);
        Arite2 v2 = new Arite2(parametres[10], w1, w3);
        
        Arite1 u1 = new Arite1(parametres[11], v1);
        Arite1 u2 = new Arite1(parametres[12], v2);
        
        Arite2 r = new Arite2(parametres[13], u1, u2);
        
        float resultatAttendu = 0;
        
        ///////////////////////////////////////////////////
        //fenetres
        
        Fenetre fenH = new Fenetre("Joueu·r·se");
        Fenetre fenIA2 = new Fenetre("IA2");
        
        int cpt = 0;

        while (true) {
           fenH.Update();
           fenIA2.Update();
           cpt++;
           
            if (cpt%1000 == 0) {
                
                for (int i = 0; i < parametres.length; i++) {
                    System.out.println("p" + i + " : " + parametres[i].getValeur()/Arbre.range);
                }
                System.out.println("");
                System.out.println("res : " + r.getValeur());
                System.out.println("");
            }
           
            /////////////////////////////////////////////////
            //IA2
                
            //Apprentissage
            if (cpt%100 == 0) {
                x1.setValeur(fenH.pan.n.getX());
                x2.setValeur(fenH.pan.b.getX());
                x3.setValeur(fenH.pan.n.getY());

                r.getValeur();

                if (fenH.pan.click) {
                    float R = 300;
                    if (fenH.pan.barreDroite) {
                        resultatAttendu =  R;
                    } else {
                        resultatAttendu = -R;
                    }

                    //normal
    //                for (Parametre parametre : parametres) {
    //                    parametre.update(resultatAttendu);
    //                }

                    //stocas t h i c c
                    parametres[(int)(Math.random()*parametres.length)].update(resultatAttendu);

                } 
            }
                        
            //Action
            
            x1.setValeur(fenIA2.pan.n.getX());
            x2.setValeur(fenIA2.pan.b.getX());
            x3.setValeur(fenIA2.pan.n.getY());
            
            float actionIA2 = r.getValeur();
            
            //System.out.println("act : " + actionIA2);
            
            if (actionIA2 < - 5) {
                actionIA2 = -1;
            } else if (actionIA2 > 5) {
                actionIA2 =  1;
            }
            
            fenIA2.pan.b.deplaceBarre((int) actionIA2, fenIA2.pan);
                     
        }        
    }    
}
