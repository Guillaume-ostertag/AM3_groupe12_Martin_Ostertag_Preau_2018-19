/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class FonctionArite2 {
    FA2f f;
    FA2f df1;
    FA2f df2;

    public FonctionArite2(FA2f f, FA2f df1, FA2f df2) {
        this.f = f;
        this.df1 = df1;
        this.df2 = df2;
    }
    
    public interface FA2f {
        float eval(float x1, float x2);
    }
}
