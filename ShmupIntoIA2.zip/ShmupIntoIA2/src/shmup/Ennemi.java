/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import java.util.List;

/**
 *
 * @author garr
 */
public class Ennemi extends Vaisseau {

    Pattern pattern;
    Trajectoire[] trajectoires;
    double phaseTrajectoire;
    double phasePattern;
    
    public Ennemi(int size, Trajectoire[] trajectoires, Pattern pattern) {
        super((int)(Math.random()*700), -50, size, 3);
        this.trajectoires = trajectoires;
        this.phaseTrajectoire = Math.random()*10;
        this.pattern = pattern;
    }
    
    public Ennemi(float x, float y,int size, Trajectoire[] trajectoires, Pattern pattern) {
        super(x, y, size, 3);
        this.trajectoires = trajectoires;
        this.phaseTrajectoire = Math.random()*10;
        this.phasePattern = Math.random()*10;
        this.pattern = pattern;
    }
    
    public Ennemi(float x, float y,int size, Trajectoire[] trajectoires, double phaseTrajectoire, double phasePattern, Pattern pattern) {
        super(x, y, size, 3);
        this.trajectoires = trajectoires;
        this.phaseTrajectoire = phaseTrajectoire;
        this.phasePattern = phasePattern;
        this.pattern = pattern;
    }
   
    @Override
    public void move() {
        for (Trajectoire t : trajectoires) {
            this.x += t.getDiffX(time2+this.phaseTrajectoire);
            this.y += t.getDiffY(time2+this.phaseTrajectoire);
        }
    }

    public void fire(List<Bullet> bullets) {
        if (this.pattern.tirePossible(time+(int)phasePattern)) {
            bullets.add(new Bullet(10, this.x, this.y, (float)this.pattern.getX(time2+phasePattern), (float)this.pattern.getY(time2+phasePattern), dammage));
        }
    }
    
}
