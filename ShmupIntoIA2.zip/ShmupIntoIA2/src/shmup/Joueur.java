/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import java.util.List;

/**
 *
 * @author garr
 */
public class Joueur extends Vaisseau {
    
    private boolean tire;
    private float vitesse;

    public Joueur(float x, float y, int size, int hp) {
        super(x, y, size, hp);
        this.vitesse = (float) 0.3;
        this.tire = false;
    }
    public void setTire(boolean tire) {
        this.tire = tire;
    }

    public float getVitesse() {
        return vitesse;
    }
    
    @Override
    public void move() {
        
        if      (this.x <  20 && this.vX < 0) this.vX = 0;
        else if (this.x > 680 && this.vX > 0) this.vX = 0;
         
        if      (this.y <  20 && this.vY < 0) this.vY = 0;
        else if (this.y > 650 && this.vY > 0) this.vY = 0;
                       
        this.setX(this.x + this.vX);
        this.setY(this.y + this.vY);
    }
    
    @Override
    public void fire(List<Bullet> bullets, float vX, float vY) {
        if (tire && Vaisseau.time%100 == 0) {
            bullets.add(new Bullet(10, x, y, vX, vY, dammage));
        }
    } 
    
}
