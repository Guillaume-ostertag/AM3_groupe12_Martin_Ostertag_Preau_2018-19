package shmup;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class Arite1 extends Operation {
    
    protected NonParametre operande;
    static protected FonctionArite1 op1;
    static protected FonctionArite1 op2;
    
    static public void InitOperations(FonctionArite1 op1, FonctionArite1 op2) {
        Arite1.op1 = op1;
        Arite1.op2 = op2;
    }
    
    public Arite1(Parametre parametre, NonParametre operande) {
        super(parametre);
        this.operande = operande;
        this.operande.setParent(this);
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) return this.valeur; 
        else {
            float a = this.parametre.getValeur();
            float x = this.operande.getValeur();
            this.valeur = (a*Arite1.op1.f.eval(x) + (Arbre.range-a)*Arite1.op2.f.eval(x))/Arbre.range;
            return this.valeur;
        }
    }  
}
