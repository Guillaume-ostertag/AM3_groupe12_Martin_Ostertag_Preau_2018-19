/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

/**
 *
 * @author garr
 */
public class Bullet {
    
    private final double friction;
    private final int force;
    private final int size;   
    private double vX;
    private double vY;
    private float x;
    private float y;
        
    public int getSize() {
        return size;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
    
    public int getForce() {
        return force;
    }

    public Bullet(int size, float x, float y, float vX, float vY, int force) {
        this.friction = 1;
        this.force = force;
        this.size = size;
        this.vX = vX;
        this.vY = vY;   
        this.x = x;
        this.y = y;
    }
    
    public Bullet(int size, float x, float y, float vX, float vY, int force, float friction) {
        this.friction = friction;
        this.force = force;
        this.size = size;
        this.vX = vX;
        this.vY = vY;   
        this.x = x;
        this.y = y;
    }
    
    public void deplacement(Panneau p){
        this.vX /= this.friction;
        this.vY /= this.friction;
        this.x  += this.vX;
        this.y  += this.vY;
    }
    
    public boolean isDestroyed(int height, int width) {
        return this.x < 0 || this.x > width || this.y < 0 || this.y > height;    
    }
   
}
