/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JPanel;
import java.util.LinkedList;
import java.util.List;

import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author garr
 */
public class Panneau extends JPanel {
    
    
    private int precision = 6;
    private boolean[][] presenceAlly         = new boolean[precision][precision];
    private boolean[][] presenceEnnemi       = new boolean[precision][precision];   
    private boolean[][] presenceAllyBullet   = new boolean[precision][precision];
    private boolean[][] presenceEnnemiBullet = new boolean[precision][precision];
    
    private List<Bullet> BulletsDetruites;
    private List<Bullet> ennemyBullets;
    private List<Bullet> allyBullets;
    private List<Ennemi> ennemis;
    private List<Ennemi> ennemisMorts;
    public  Joueur joueur;
    public  Joueur joueur2;
    
    public Arbre2D ia;
    
    
    Image vaisseauPrincipal;
    Image vaisseauEnnemi;
    Image fondEcran;
    Image planete;
    Image vaisseauIA;
    
    Image[] planetes;
    
    ImageObserver imageTest = null;
    double xScrolling = Math.random() * 750-100;
    double yScrolling = 700;
    
    Trajectoire[] t1  = {new Trajectoire((t)-> 0                ,(t)-> 0.1              ),
                         new Trajectoire((t)-> Math.sin(t*1/4)/4,(t)-> 0                ),
                         new Trajectoire((t)-> 0                ,(t)-> Math.sin(t*1/2)/6)};
        
    Trajectoire[] t2  = {new Trajectoire((t)-> 0                ,(t)-> 0.1              ),
                         new Trajectoire((t)-> Math.sin(t*1/4)/8,(t)-> Math.cos(t*1/4)/8)};
    
    Pattern p1 = new Pattern((t) -> 150, (t) -> Math.PI/2+Math.sin(t*4)*0.4, (t) -> 0.25); 
    Pattern p2 = new Pattern((t) -> 100, (t) -> t*15, (t) -> 0.3);
  
    public Panneau (){
                
        try                    { vaisseauPrincipal = ImageIO.read(new File("Images/Vaisseau principal.png"));}
        catch (IOException ex) { Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);}
        try                    { vaisseauIA = ImageIO.read(new File("Images/Vaisseau principal2.png"));}
        catch (IOException ex) { Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);}
        try                    { vaisseauEnnemi    = ImageIO.read(new File("Images/Vaisseau ennemi 1x2.png"));}
        catch (IOException ex) { Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);}       
        try                    { fondEcran         = ImageIO.read(new File("Images/Espace.png"));}
        catch (IOException ex) { Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);}
        
        String[] imagesPlanetesPath =  {"Images/PlaneteJaune.png",
                                        "Images/PlaneteBleueVague.png",
                                        "Images/Comète blanche.png",
                                        "Images/Planète terre.png",
                                        "Images/PlaneteRouge.png"};
        
        this.planetes = new Image[imagesPlanetesPath.length];      
        for (int i = 0; i < planetes.length; i++) {
            try { this.planetes[i] = ImageIO.read(new File(imagesPlanetesPath[i]));}
            catch (IOException ex) { Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);}
        }

        this.BulletsDetruites = new LinkedList<>();
        this.ennemyBullets = new LinkedList<>();
        this.ennemisMorts = new LinkedList<>();
        this.allyBullets = new LinkedList<>();
        this.ennemis = new LinkedList<>();
        
        this.joueur  =   new Joueur(350, 600, this.vaisseauPrincipal.getHeight(imageTest), 10);
        this.joueur2 =   new Joueur(400, 600, this.vaisseauPrincipal.getHeight(imageTest), 10);
        this.ennemis.add(new Ennemi(200,   0, this.vaisseauEnnemi.getHeight(imageTest),t1,p1));
        this.ennemis.add(new Ennemi(400,   0, this.vaisseauEnnemi.getHeight(imageTest),t2,p1));
  
        this.ia = new Arbre2D(precision);
        this.joueur2.setTire(true);
        
        FonctionArite2 addition       = new FonctionArite2((a, b) -> a+b, (a, b) ->  1, (a, b) ->  1);
        FonctionArite2 soustraction   = new FonctionArite2((a, b) -> a-b, (a, b) -> -1, (a, b) -> -1);
        FonctionArite2 multiplication = new FonctionArite2((a, b) -> a*b, (a, b) ->  b, (a, b) ->  a);
        FonctionArite2 minimum        = new FonctionArite2((a, b) -> Math.min(a, b), (float a, float b) -> a < b ? 1 : b, (a, b) -> a < b ? a : 1);
        
        FonctionArite1 sinus    = new FonctionArite1((a) -> (float)Math.sin(a), (a) -> (float)Math.cos(a));
        FonctionArite1 inverse  = new FonctionArite1((a) -> 1/a, (a) -> -1/(a*a));
        FonctionArite1 negatif  = new FonctionArite1((a) -> -a,  (a) -> -1); //somehow brocken??
        FonctionArite1 carre    = new FonctionArite1((a) -> a*a, (a) -> 2*a);
        FonctionArite1 identite = new FonctionArite1((a) -> a,   (a) -> 1);
        FonctionArite1 elemNeutreAdd  = new FonctionArite1((a) -> 0,   (a) -> 0);
        FonctionArite1 elemNeutreMult = new FonctionArite1((a) -> 1,   (a) -> 0);
        
        Arite1.InitOperations(elemNeutreAdd, identite);
        Arite2.InitOperations(soustraction, addition);
                
    }
    
    @Override
    public void paintComponent(Graphics g){
        
        g.drawImage(fondEcran, 0, 0, imageTest);
        
        if (yScrolling <= 700){
            g.drawImage(planete,(int) xScrolling, (int) yScrolling, imageTest);
            yScrolling += 0.1;
        } else {  
            yScrolling = -300;
            xScrolling = Math.random()*750 - 100;
            planete = planetes[(int)(Math.random()*planetes.length)] ;
        }
        
        double l = 0.8;
        
        ennemyBullets.forEach((b) -> {
            g.setColor(Color.ORANGE);
            g.fillOval((int) (b.getX()-(b.getSize()*1/2)), (int)(b.getY()-(b.getSize()*1/2)), (int)(b.getSize()*1), (int)(b.getSize()*1));
            g.setColor(Color.WHITE);
            g.fillOval((int) (b.getX()-(b.getSize()*l/2)), (int)(b.getY()-(b.getSize()*l/2)), (int)(b.getSize()*l), (int)(b.getSize()*l));
        });
        
        allyBullets.forEach((b) -> {
            g.setColor(Color.CYAN);
            g.fillOval((int) (b.getX()-(b.getSize()*1/2)), (int)(b.getY()-(b.getSize()*1/2)), (int)(b.getSize()*1), (int)(b.getSize()*1));
            g.setColor(Color.WHITE);
            g.fillOval((int) (b.getX()-(b.getSize()*l/2)), (int)(b.getY()-(b.getSize()*l/2)), (int)(b.getSize()*l), (int)(b.getSize()*l));
        });
       
        ennemis.forEach((b) -> {
            g.drawImage(vaisseauEnnemi,(int) b.getX()-b.getSize()/2, (int)b.getY()-b.getSize()/2, imageTest);
        });
        
        
        g.drawImage(vaisseauPrincipal, (int) joueur.getX()-joueur.getSize()/2  , (int)joueur.getY()-joueur.getSize()/2, imageTest);
        g.drawImage(vaisseauIA       , (int) joueur2.getX()-joueur2.getSize()/2, (int)joueur2.getY()-joueur2.getSize()/2, imageTest);
       
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(700, 0, 700, 700);
        int c = 350/precision;
        int x = 705;
        int y = 0;
        
        for (int i = 0; i < precision; i++) {
            for (int j = 0; j < precision; j++) {
                
                g.setColor(this.presenceAlly[i][j]         ? Color.BLUE   : Color.BLACK);
                g.fillRect(      x,       y, c, c);
                g.setColor(this.presenceAllyBullet[i][j]   ? Color.CYAN   : Color.BLACK);
                g.fillRect(      x, 350 + y, c, c);
                g.setColor(this.presenceEnnemi[i][j]       ? Color.RED    : Color.BLACK);
                g.fillRect(350 + x,       y, c, c);
                g.setColor(this.presenceEnnemiBullet[i][j] ? Color.ORANGE : Color.BLACK);
                g.fillRect(350 + x, 350 + y, c, c);
            
                y += c;
            }
            y = 0;
            x += c;
        }
        
    }
    
    
    public void update(){
        
        for (int i = 0; i < precision; i++) {
            for (int j = 0; j < precision; j++) {
                try {this.presenceAlly[i][j]         = false;} catch (Exception e) {}
                try {this.presenceEnnemi[i][j]       = false;} catch (Exception e) {} 
                try {this.presenceAllyBullet[i][j]   = false;} catch (Exception e) {} 
                try {this.presenceEnnemiBullet[i][j] = false;} catch (Exception e) {} 
            }
        }
        
        //spawn des ennemis
        if (Math.random() < 0.001 && this.ennemis.size() < 4) {
            this.ennemis.add(new Ennemi(40, Math.random() < 0.2 ? t1 : t2, Math.random() < 0.5 ? p1 : p2));
        }
        
        Vaisseau.timeInc();
        
        if (Vaisseau.time%100 == 0) {
            double[][] valeurs = new double[precision][precision];
            for (int i = 0; i < this.precision; i++) {
                for (int j = 0; j < this.precision; j++) {
                    if (this.presenceEnnemiBullet[i][j]) valeurs[i][j] =  10;
                    valeurs[(int)(joueur.getX()*precision/700)][(int)(joueur.getY()*precision/700)] = -20;
                }
            }
            ia.getResultat(valeurs,0);
            ia.update(this.joueur.getvX());
            for (int i = 0; i < this.precision; i++) {
                for (int j = 0; j < this.precision; j++) {
                    if (this.presenceEnnemiBullet[i][j]) valeurs[i][j] =  10;
                    valeurs[(int)(joueur2.getX()*precision/700)][(int)(joueur2.getY()*precision/700)] = -20;
                }
            }
            ia.getResultat(valeurs,0);
            joueur2.vX = joueur2.getVitesse() * (ia.getResultat(valeurs, 0) < 0 ? -1 : 1);
            joueur2.vY = joueur2.getVitesse() * (ia.getResultat(valeurs, 1) < 0 ? -1 : 1);
        }
        
        joueur2.move();
        joueur2.fire(allyBullets, (float)  0   , (float) -0.5 );
        joueur2.fire(allyBullets, (float) -0.05, (float) -0.45);
        joueur2.fire(allyBullets, (float)  0.05, (float) -0.45);
        
        //actions du joueur
        joueur.move();
        joueur.fire(allyBullets, (float)  0   , (float) -0.5 );
        joueur.fire(allyBullets, (float) -0.05, (float) -0.45);
        joueur.fire(allyBullets, (float)  0.05, (float) -0.45);
        try {this.presenceAlly[(int)(joueur.getX()*precision/700)][(int)(joueur.getY()*precision/700)] = true;} catch (Exception e) {}
        //
        
        //autres actions
        for (Bullet b : ennemyBullets) {
            b.deplacement(this);
            if (b.getX()-b.getSize()/2 < joueur.getX()+joueur.getSize()/2 &&
                b.getX()+b.getSize()/2 > joueur.getX()-joueur.getSize()/2 &&
                b.getY()-b.getSize()/2 < joueur.getY()+joueur.getSize()/2 &&
                b.getY()+b.getSize()/2 > joueur.getY()-joueur.getSize()/2 ) {
                
                this.joueur.takeDamage(b.getForce());
                this.BulletsDetruites.add(b);
            }
            if (b.isDestroyed(700, 700)) this.BulletsDetruites.add(b);
            else {
                try {this.presenceEnnemiBullet[(int)(b.getX()*precision/700)][(int)(b.getY()*precision/700)] = true;} catch (Exception e) {} 
            }
        }
        
        for (Bullet b : allyBullets) {
            b.deplacement(this);
            if (b.isDestroyed(700, 700)) this.BulletsDetruites.add(b);
            else {
                try {this.presenceAllyBullet[(int)(b.getX()*precision/700)][(int)(b.getY()*precision/700)] = true;} catch (Exception e) {} 
            }
        }

        for (Ennemi v : ennemis) {
            
            v.move();
            v.fire(ennemyBullets);
            
            if (v.getX()-v.getSize()/2 < joueur.getX()+joueur.getSize()/2 &&
                v.getX()+v.getSize()/2 > joueur.getX()-joueur.getSize()/2 &&
                v.getY()-v.getSize()/2 < joueur.getY()+joueur.getSize()/2 &&
                v.getY()+v.getSize()/2 > joueur.getY()-joueur.getSize()/2 ) {
                this.ennemisMorts.add(v);
                this.joueur.takeDamage(10);
            }
            
            for (Bullet b : allyBullets) {
                if (b.getX()-b.getSize()/2 < v.getX()+v.getSize()/2 &&
                    b.getX()+b.getSize()/2 > v.getX()-v.getSize()/2 &&
                    b.getY()-b.getSize()/2 < v.getY()+v.getSize()/2 &&
                    b.getY()+b.getSize()/2 > v.getY()-v.getSize()/2 ) {       
                    v.takeDamage(b.getForce());
                    this.BulletsDetruites.add(b);
                }
            }
            
            if (v.isDestroyed(this.getHeight(), this.getWidth())) this.ennemisMorts.add(v);
            else {
                try {this.presenceEnnemi[(int)(v.getX()*precision/700)][(int)(v.getY()*precision/700)] = true;} catch (Exception e) {} 
            }
        }
        
        //clean la memoire
        for (Ennemi v : ennemisMorts) {
            this.ennemis.remove(v);
        }
        this.ennemisMorts.clear();
        
        for (Bullet b : BulletsDetruites) {
            this.allyBullets.remove(b);
            this.ennemyBullets.remove(b);
        }
        this.BulletsDetruites.clear();
        //
    }
}
