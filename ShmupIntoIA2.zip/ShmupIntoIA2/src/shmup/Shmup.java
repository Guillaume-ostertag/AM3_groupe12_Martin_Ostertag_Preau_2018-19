/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import javax.swing.JFrame;

/**
 *
 * @author garr
 */
public class Shmup {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fenetre fen = new Fenetre();
        fen.setTitle("Shmup");
        fen.setSize(1400, 700);
        fen.setLocationRelativeTo(null);
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
        fen.setVisible(true);
        fen.setResizable(false);
        
//        Fenetre fen2 = new Fenetre();
//        fen2.setTitle("Shmup2");
//        fen2.setSize(700, 700);
//        fen2.setLocationRelativeTo(null);
//        fen2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
//        fen2.setVisible(true);
//        fen2.setResizable(false);
        
        while(true) {
            fen.Update();
            //fen2.Update();
        }
    }
    
}
