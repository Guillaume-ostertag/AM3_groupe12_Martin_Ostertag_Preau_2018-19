/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Baptiste
 */
public class Arbre2D {
    
    public Arite2[] sorties;
    public Observation[][] entrees;
    
    public List<Parametre> parametres = new LinkedList<>();
    
    public Arbre2D (int taille){
        
        this.entrees = new Observation [taille][taille];
        
        for (int i = 0; i < taille; i++) {
            for (int j = 0; j < taille; j++) {
                this.entrees[i][j] = new Observation();
                parametres.add(new Parametre());
            }
        }
        
        NonParametre[][] arbres = this.entrees;
        int cpt = 1;
        while(cpt < taille-3){
            
            Operation[][] ok = new Operation [taille-cpt][taille-cpt];
            for (int i = 0; i < ok.length-cpt; i++) {
                for (int j = 0; j < ok.length-cpt; j++) {
                    Parametre p = new Parametre();
                    ok[i][j] = new Arite2(p, arbres[(int) (Math.random()*(arbres.length-1))][(int) (Math.random()*(arbres.length-1))], arbres[(int) (Math.random()*(arbres.length-1))][(int) (Math.random()*(arbres.length-1))]);
                    parametres.add(p);
                }
            }
            arbres = ok;
            cpt++;
        }
        
        this.sorties = new Arite2[2];
        
        this.sorties[0] = (Arite2)arbres[0][0];
        this.sorties[1] = (Arite2)arbres[1][1];
    }
    
    public void update(double r) {
        for (Parametre p : this.parametres) {
            p.calculGradient((float) r);
        }
    }
   
    public double getResultat(double [][] a, int s){
        
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length; j++) {
                this.entrees[i][j].setValeur((float) a[i][j]);
            }
        }
        
        return this.sorties[s].getValeur();
    }
    
}
