/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shmup;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author garr
 */
public class Fenetre extends JFrame {
    public Panneau pan;
    private boolean clicGauche = false;
        
    public void start() {
        
    }
    
    public Fenetre() {
        
        pan = new Panneau();
        
        pan.addKeyListener(new KeyAdapter(){

            @Override
            public void keyReleased(KeyEvent e) {
    
                switch (e.getKeyChar()) {
                    case 'Z' : 
                    case 'z' : pan.joueur.setvY(0); break;
                    case 'Q' : 
                    case 'q' : pan.joueur.setvX(0); break;
                    case 'S' : 
                    case 's' : pan.joueur.setvY(0); break;
                    case 'D' : 
                    case 'd' : pan.joueur.setvX(0); break;
                    case 'O' : 
                    case 'o' :
                    case '1' : pan.joueur.setTire(false); break;
                    case '2' : break;
                }
            }
                        
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyChar()) {
                    case 'Z' :
                    case 'z' : pan.joueur.setvY(-pan.joueur.getVitesse()); break;
                    case 'Q' :
                    case 'q' : pan.joueur.setvX(-pan.joueur.getVitesse()); break;
                    case 'S' :
                    case 's' : pan.joueur.setvY( pan.joueur.getVitesse()); break;
                    case 'D' :
                    case 'd' : pan.joueur.setvX( pan.joueur.getVitesse()); break;
                    case 'O' :
                    case 'o' :
                    case '1' : pan.joueur.setTire(true); break;
                    case '2' : System.out.println("bombe pas encore supportée"); break;
                }
            }
        });
        
//        pan.addMouseListener(new MouseAdapter(){
//     
//            @Override
//            public void mousePressed(MouseEvent e){
//                clicGauche = SwingUtilities.isLeftMouseButton(e);
//                pan.joueur.setTire(!SwingUtilities.isLeftMouseButton(e));
//            }
//                   
//            @Override
//            public void mouseReleased(MouseEvent e){
//                if (SwingUtilities.isLeftMouseButton(e)) {
//                    pan.joueur.setvY(0);
//                    pan.joueur.setvX(0);
//                    clicGauche = false;
//                } else {
//                    pan.joueur.setTire(false);
//                }
//            }
//        });
        
        pan.setFocusable(true);
        pan.requestFocus();
        
        this.setContentPane(pan);
    }
    
    public void Update(){
        
//        if (this.clicGauche) {
//            Point p = MouseInfo.getPointerInfo().getLocation();
//            p = new Point(p.x - this.getLocation().x, p.y - this.getLocation().y - pan.joueur.size/2);
//            
//            float dx = pan.joueur.getX()-p.x;
//            float dy = pan.joueur.getY()-p.y;           
//            float norm = (float) Math.sqrt(dx*dx+dy*dy);
//            
//            pan.joueur.setvX(-pan.joueur.getVitesse()*dx/norm);
//            pan.joueur.setvY(-pan.joueur.getVitesse()*dy/norm);
//        } else {
//            pan.joueur.setvY(0);
//            pan.joueur.setvX(0);
//        }
        
        pan.update();
        pan.repaint();
        
        try {
            Thread.sleep(0,1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
