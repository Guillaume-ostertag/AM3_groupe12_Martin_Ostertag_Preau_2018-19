/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

/**
 *
 * @author garr
 */
public class Trajectoire {
    
    public interface Composante {
        double eval(double t);
    }
    
    private final Composante diffX;
    private final Composante diffy;
    private final Composante scalaireX;
    private final Composante scalaireY;

    public Trajectoire() {
        this.diffX = ((t) -> 0);
        this.diffy = ((t) -> 0);
        this.scalaireX = ((t) -> 1);
        this.scalaireY = ((t) -> 1);
    }
    
    public Trajectoire(Composante x, Composante y) {
        this.diffX = x;
        this.diffy = y;
        this.scalaireX = ((t) -> 1);
        this.scalaireY = ((t) -> 1);
    }
    
    public Trajectoire(Composante x, Composante scalaireX, Composante y, Composante scalaireY) {
        this.diffX = x;
        this.diffy = y;
        this.scalaireX = scalaireX;
        this.scalaireY = scalaireY;
    }
    
    public Trajectoire(Composante x, Composante scalaireX, Composante y, Composante scalaireY, double phase) {
        this.diffX = x;
        this.diffy = y;
        this.scalaireX = scalaireX;
        this.scalaireY = scalaireY;
    }
    
    public double getDiffX(double temps) {
        return this.diffX.eval(temps)*this.scalaireX.eval(temps);
    }
    
    public double getDiffY(double temps) {
        return this.diffy.eval(temps)*this.scalaireY.eval(temps);
    }
        
}
