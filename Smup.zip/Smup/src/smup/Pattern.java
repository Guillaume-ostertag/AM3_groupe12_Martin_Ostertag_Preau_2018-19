/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

/**
 *
 * @author garr
 */
public class Pattern {
    
    public interface Composante {
        double eval(double t);
    }
    
    private final Composante periode;
    private final Composante vitesse;
    private final Composante angle;
    
    public Pattern(Composante periode, Composante angle, Composante vitesse) {
        this.periode = periode;
        this.vitesse = vitesse;
        this.angle   = angle;
    }
    
    public boolean tirePossible(int temps) {
        return temps%(int)this.periode.eval(temps) == 0;
    }
    
    public double getX(double temps) {
        return Math.cos(this.angle.eval(temps))*this.vitesse.eval(temps);
    }
    
    public double getY(double temps) {
        return Math.sin(this.angle.eval(temps))*this.vitesse.eval(temps);
    }
    
}
