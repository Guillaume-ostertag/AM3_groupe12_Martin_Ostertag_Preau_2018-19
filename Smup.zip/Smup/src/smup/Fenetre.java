/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javafx.stage.Stage;
import javax.swing.JFrame;

/**
 *
 * @author garr
 */
public class Fenetre extends JFrame {
    public Panneau pan;
    
    public void start(Stage stage) {
        
    }
    
    public Fenetre() {
        
        pan = new Panneau();
        
        pan.addKeyListener(new KeyAdapter(){
            
            @Override
            public void keyReleased(KeyEvent e) {
                char c = e.getKeyChar();
                
                switch (c) {
                    case 'Z' : 
                    case 'z' : pan.joueur.setvY(0); break;
                    case 'Q' : 
                    case 'q' : pan.joueur.setvX(0); break;
                    case 'S' : 
                    case 's' : pan.joueur.setvY(0); break;
                    case 'D' : 
                    case 'd' : pan.joueur.setvX(0); break;
                    case 'O' : 
                    case 'o' :
                    case '1' : pan.joueur.setTire(false); break;
                    case '2' : break;
                }
            }
                        
            @Override
            public void keyPressed(KeyEvent e) {
                char c = e.getKeyChar();
                switch (c) {
                    case 'Z' :
                    case 'z' : pan.joueur.setvY(-pan.joueur.getVitesse()); break;
                    case 'Q' :
                    case 'q' : pan.joueur.setvX(-pan.joueur.getVitesse()); break;
                    case 'S' :
                    case 's' : pan.joueur.setvY( pan.joueur.getVitesse()); break;
                    case 'D' :
                    case 'd' : pan.joueur.setvX( pan.joueur.getVitesse()); break;
                    case 'O' :
                    case 'o' :
                    case '1' : pan.joueur.setTire(true); break;
                    case '2' : System.out.println("bombe pas encore supportée"); break;
                }  
            }
        });
        
        pan.setFocusable(true);
        pan.requestFocus();
        
        this.setContentPane(pan);

    }
    
    public void Update(){
            pan.update();
            pan.repaint();
            try {
                Thread.sleep(0,1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    
}
