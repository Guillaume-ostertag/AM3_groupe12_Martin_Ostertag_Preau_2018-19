/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

import java.util.Vector;

/**
 *
 * @author garr
 */
public class Ennemi extends Vaisseau {

    Pattern pattern;
    Trajectoire[] trajectoires;
    double phase;
    
    public Ennemi(int size, Trajectoire[] trajectoires, Pattern pattern) {
        super((int)(Math.random()*700), -50, size, 3);
        this.trajectoires = trajectoires;
        this.phase = Math.random()*10;
        this.pattern = pattern;
    }
    
    public Ennemi(float x, float y,int size, Trajectoire[] trajectoires, Pattern pattern) {
        super(x, y, size, 3);
        this.trajectoires = trajectoires;
        this.phase = Math.random()*10;
        this.pattern = pattern;
    }
    
    public Ennemi(float x, float y,int size, Trajectoire[] trajectoires, double phase, Pattern pattern) {
        super(x, y, size, 3);
        this.trajectoires = trajectoires;
        this.phase = phase;
        this.pattern = pattern;
    }
   
    @Override
    public void move() {
        for (Trajectoire t : trajectoires) {
            this.x += t.getDiffX(time2+this.phase);
            this.y += t.getDiffY(time2+this.phase);
        }
    }

    @Override
    public void fire(Vector<Bullet> bullets, float vX, float vY) {
        if (this.pattern.tirePossible(time)) {
            bullets.add(new Bullet(10, this.x, this.y, (float)this.pattern.getX(time2+phase), (float)this.pattern.getY(time2+phase), dammage));
        }
    }
    
}
