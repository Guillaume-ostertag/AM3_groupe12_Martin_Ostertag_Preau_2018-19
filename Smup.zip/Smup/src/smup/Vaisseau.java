/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

import java.util.Vector;

/**
 *
 * @author garr
 */
public abstract class Vaisseau {
    
    static protected int    time  = 0;
    static protected double time2 = 0;
    
    protected int dammage;
    protected int hp;

    protected int size;
    protected float x;
    protected float y;
    protected float vX;
    protected float vY;
    
    public Vaisseau(float x, float y, int size, int hp){
        this.x = x;
        this.y = y;
        this.vX = 0;
        this.vY = 0;
        this.hp = hp;
        this.size = size;
        this.dammage = 1;
    }
    
    public int getSize() {
        return size;
    }
    public float getX() {
        return x;
    }
    public float getY() {
        return y;
    }
    public float getvX() {
        return vX;
    }
    public float getvY() {
        return vY;
    }

    public void setX(float x) {
        this.x = x;
    }
    public void setY(float y) {
        this.y = y;
    }
    public void setvX(float vX) {
        this.vX = vX;
    }
    public void setvY(float vY) {
        this.vY = vY;
    }
    
    static public void timeInc() {
        Vaisseau.time ++;
        Vaisseau.time2 += 0.01;
    }
    
    public void move() {
        this.setX(this.x + this.vX);
        this.setY(this.y + this.vY);
    }
    
    public void fire(Vector<Bullet> bullets, float vX, float vY) {
        if (Vaisseau.time%100 == 0) {
            bullets.add(new Bullet(10, x, y, vX, vY, dammage));
        }
    }
    
    public void takeDamage(int d){
        this.hp -= d;
    }
    
    public boolean isDestroyed(int height, int width) {
        return this.hp < 0 || this.x < -50 || this.x > width+50 || this.y < -100 || this.y > height+50;
    }
    
}
