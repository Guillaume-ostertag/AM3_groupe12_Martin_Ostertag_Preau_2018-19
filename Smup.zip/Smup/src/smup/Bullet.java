/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

/**
 *
 * @author garr
 */
public class Bullet {
    
    private final int force;
    private final int size;
    private final float vX;
    private final float vY;
    private float x;
    private float y;
    
    public int getSize() {
        return size;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
    
    public int getForce() {
        return force;
    }

    public Bullet(int size, float x, float y, float vX, float vY, int force) {
        this.size = size;
        this.x = x;
        this.y = y;
        this.vX = vX;
        this.vY = vY;
        this.force = force;
    }
    
    public void deplacement(Panneau p){
        this.x  += this.vX;
        this.y  += this.vY;
    }
    
    public boolean isDestroyed(int height, int width) {
        return this.x < 0 || this.x > width || this.y < 0 || this.y > height;    
    }
   
}
