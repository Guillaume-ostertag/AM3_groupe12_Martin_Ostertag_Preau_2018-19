/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JPanel;
import java.util.Vector;

import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
 

/**
 *
 * @author garr
 */
public class Panneau extends JPanel {
    
    private Vector<Bullet> BulletsDetruites;
    private Vector<Bullet> ennemyBullets;
    private Vector<Bullet> allyBullets;
    private Vector<Vaisseau> ennemis;
    private Vector<Vaisseau> ennemisMorts;
    public  Joueur joueur;
    
    Image vaisseauPrincipal;
    Image vaisseauEnnemi;
    Image fondEcran;
    Image planeteJaune;
    Image planeteBleue;
    Image planeteComete;
    Image planeteTerre;
    Image planete;
    
    ImageObserver imageTest = null;
    double xScrolling = Math.random() * 750-100;
    double yScrolling = 700;
    
    Trajectoire[] t1  = {new Trajectoire((t)-> 0                ,(t)-> 0.1              ),
                         new Trajectoire((t)-> Math.sin(t*1/4)/4,(t)-> 0                ),
                         new Trajectoire((t)-> 0                ,(t)-> Math.sin(t*3/2)/4)};
        
    Trajectoire[] t2  = {new Trajectoire((t)-> 0                ,(t)-> 0.1              ),
                         new Trajectoire((t)-> Math.sin(t*1/4)/8,(t)-> Math.cos(t*1/4)/8)};
    
    Pattern p1 = new Pattern((t) -> 100, (t) -> Math.PI/2+Math.sin(t*5)*0.4, (t) -> 0.3);
    
    Pattern p2 = new Pattern((t) -> 100, (t) -> t*15, (t) -> 0.3);
  
    public Panneau (){
        
        try {
            vaisseauPrincipal = ImageIO.read(new File("Images/Vaisseau principalx2.png"));
            vaisseauEnnemi    = ImageIO.read(new File("Images/Vaisseau ennemi 1x2.png"));
            fondEcran         = ImageIO.read(new File("Images/Espace.png"));
            planeteJaune      = ImageIO.read(new File("Images/PlaneteJaune.png"));
            planeteBleue      = ImageIO.read(new File("Images/PlaneteBleueVague.png"));
            planeteComete     = ImageIO.read(new File("Images/Comète blanche.png"));
            planeteTerre      = ImageIO.read(new File("Images/Planète terre.png"));       
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
               
        this.joueur = new Joueur(350, 600, 40, 10);
        this.ennemis = new Vector();
        this.allyBullets = new Vector();
        this.BulletsDetruites = new Vector();
        this.ennemyBullets = new Vector();
        this.ennemisMorts = new Vector();
                
        this.ennemis.add(new Ennemi(200, 0, 40,t1,p1));
        this.ennemis.add(new Ennemi(400, 0, 40,t2,p1));
                        
    }
    
    @Override
    public void paintComponent(Graphics g){
        
        g.drawImage(fondEcran,0,0, imageTest);
        //g.setColor(Color.BLACK); g.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        if (yScrolling <= 700){
            g.drawImage(planete,(int) xScrolling, (int) yScrolling, imageTest);
            yScrolling=yScrolling + 0.1;
        } else {
            
            yScrolling = -300;
            xScrolling = Math.random() * 750-100;
          
            switch ((int)(Math.random()*4)) {
                case 0  : planete = planeteJaune; break;
                case 1  : planete = planeteBleue; break;
                case 2  : planete = planeteComete; break;
                case 3  : planete = planeteTerre; break;
                default : break;
            }
        }
        
        double l = 0.8;
        
        ennemyBullets.forEach((b) -> {
            g.setColor(Color.ORANGE);
            g.fillOval((int) (b.getX()-(b.getSize()*1/2)), (int)(b.getY()-(b.getSize()*1/2)), (int)(b.getSize()*1), (int)(b.getSize()*1));
            g.setColor(Color.WHITE);
            g.fillOval((int) (b.getX()-(b.getSize()*l/2)), (int)(b.getY()-(b.getSize()*l/2)), (int)(b.getSize()*l), (int)(b.getSize()*l));
        });
        
        allyBullets.forEach((b) -> {
            g.setColor(Color.CYAN);
            g.fillOval((int) (b.getX()-(b.getSize()*1/2)), (int)(b.getY()-(b.getSize()*1/2)), (int)(b.getSize()*1), (int)(b.getSize()*1));
            g.setColor(Color.WHITE);
            g.fillOval((int) (b.getX()-(b.getSize()*l/2)), (int)(b.getY()-(b.getSize()*l/2)), (int)(b.getSize()*l), (int)(b.getSize()*l));
        });
        
        g.setColor(Color.RED);
        ennemis.forEach((b) -> {
            g.drawImage(vaisseauEnnemi,(int) b.getX()-b.getSize()/2, (int)b.getY()-b.getSize()/2, imageTest);
            //g.fillRect((int) b.getX()-b.getSize()/2, (int)b.getY()-b.getSize()/2, b.getSize(), b.getSize());
        });
        
        g.drawImage(vaisseauPrincipal, (int) joueur.getX()-joueur.getSize()/2, (int)joueur.getY()-joueur.getSize()/2, imageTest);
        //g.setColor(Color.BLUE); g.fillRect((int) joueur.getX()-joueur.getSize()/2, (int)joueur.getY()-joueur.getSize()/2, joueur.getSize(), joueur.getSize());
    }      
  
    public void update(){
        
        //spawn des ennemis
        if (Math.random() < 0.001 && this.ennemis.size() < 4) {
            this.ennemis.add(new Ennemi(40, Math.random() < 0.2 ? t1 : t2, Math.random() < 0.5 ? p1 : p2));
        }
        
        Vaisseau.timeInc();
        
        //actions du joueur
        joueur.move();
        joueur.fire(allyBullets, (float)  0   , (float) -0.5 );
        joueur.fire(allyBullets, (float) -0.05, (float) -0.45);
        joueur.fire(allyBullets, (float)  0.05, (float) -0.45);
        //
        
        //autres actions
        for (Bullet b : ennemyBullets) {
            b.deplacement(this);
            if (b.getX()-b.getSize()/2 < joueur.getX()+joueur.getSize()/2 &&
                b.getX()+b.getSize()/2 > joueur.getX()-joueur.getSize()/2 &&
                b.getY()-b.getSize()/2 < joueur.getY()+joueur.getSize()/2 &&
                b.getY()+b.getSize()/2 > joueur.getY()-joueur.getSize()/2 ) {
                
                this.joueur.takeDamage(b.getForce());
                this.BulletsDetruites.add(b);
            }
            if (b.isDestroyed(this.getHeight(), this.getWidth())) this.BulletsDetruites.add(b);
        }
        
        for (Bullet b : allyBullets) {
            b.deplacement(this);
            if (b.isDestroyed(this.getHeight(), this.getWidth())) this.BulletsDetruites.add(b);
        }

        for (Vaisseau v : ennemis) {  
            v.move();
            
            float dx = joueur.getX()-v.getX();
            float dy = joueur.getY()-v.getY();
            
            float norm = (float) Math.sqrt(dx*dx+dy*dy)*5;
            
            v.fire(ennemyBullets, dx/norm, dy/norm);
            
            if (v.getX()-v.getSize()/2 < joueur.getX()+joueur.getSize()/2 &&
                v.getX()+v.getSize()/2 > joueur.getX()-joueur.getSize()/2 &&
                v.getY()-v.getSize()/2 < joueur.getY()+joueur.getSize()/2 &&
                v.getY()+v.getSize()/2 > joueur.getY()-joueur.getSize()/2 ) {
                
                this.ennemisMorts.add(v);
                this.joueur.takeDamage(10);
            }
            
            for (Bullet b : allyBullets) {
                if (b.getX()-b.getSize()/2 < v.getX()+v.getSize()/2 &&
                    b.getX()+b.getSize()/2 > v.getX()-v.getSize()/2 &&
                    b.getY()-b.getSize()/2 < v.getY()+v.getSize()/2 &&
                    b.getY()+b.getSize()/2 > v.getY()-v.getSize()/2 ) {
                    
                    v.takeDamage(b.getForce());
                    this.BulletsDetruites.add(b);
                }
            }
            
            if (v.isDestroyed(this.getHeight(), this.getWidth())) this.ennemisMorts.add(v);
        }
        
        //clean la memoire
        for (Vaisseau v : ennemisMorts) {
            this.ennemis.remove(v);
        }
        this.ennemisMorts.clear();
        
        for (Bullet b : BulletsDetruites) {
            this.allyBullets.remove(b);
            this.ennemyBullets.remove(b);
        }
        this.BulletsDetruites.clear();
        //
    }
}
