/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smup;

import javax.swing.JFrame;

/**
 *
 * @author garr
 */
public class Smup {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fenetre fen = new Fenetre();
        fen.setTitle("Shmup");
        fen.setSize(700, 700);
        fen.setLocationRelativeTo(null);
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
        fen.setVisible(true);
        fen.setResizable(false);
        
        while(true) {
            fen.Update();
        }
    }
    
}
