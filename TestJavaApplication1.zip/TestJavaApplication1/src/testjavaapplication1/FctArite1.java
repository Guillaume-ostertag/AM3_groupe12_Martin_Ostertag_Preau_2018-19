/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author Miggy
 */
public abstract class FctArite1 extends Operation{
    
    public String fctA1;
    
    public String fctA2;
    
    /**
     *
     * @param parametre
     * @param fctA1
     * @param fctA2
     */
    public FctArite1 (Parametre parametre, String fctA1, String fctA2)  {
        super(parametre);
        this.fctA1 = "(float)1.0/x";
        this.fctA2 = "x";      
    }
  
}
