/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class TestJavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        
        Parametre p1 = new Parametre();
        Parametre p2 = new Parametre();

        Arite1 a1_1 = new Arite1(p1, x1);
        Arite1 a1_2 = new Arite1(p2, x2);
        Parametre p3 = new Parametre();
        Arite2 y = new Arite2(p3, a1_1, a1_2);
        
        Observation x4 = new Observation();
        Parametre p4 = new Parametre();
        Parametre p5 = new Parametre();
        Arite1 a1_4 = new Arite1(p4, x4);
        Arite1 z = new Arite1(p5, a1_4);
        float erreur_moyenne;
        erreur_moyenne = (float)0.0;
        float erreur;
        int i;
        for (i = 0 ; i < 5000 ; i++) {
//            x1.setValeur((float)Math.random());
//            x2.setValeur((float)Math.random());        
//            float resultatAttendu = x1.getValeur()*x2.getValeur();
//            
//            System.out.println("a1_1 : " + a1_1.getValeur());
//            System.out.println("p1 : " + p1.getValeur());
//            System.out.println("p2 : " + p2.getValeur());
//            System.out.println("p3 : " + p3.getValeur());
//            erreur = resultatAttendu - y.getValeur();
//            System.out.println("ERREUR : " + erreur);
//            erreur_moyenne += erreur;
//            p1.update(resultatAttendu);
//            System.out.println("/////");
//            p2.update(resultatAttendu);
//            System.out.println("/////");
//            p3.update(resultatAttendu);
//            System.out.println("/////");
//            
            x4.setValeur((float)Math.random()*100);
            float resultatAttendu = x4.getValeur();
            p4.update(resultatAttendu);
            p5.update(resultatAttendu);
            erreur = Math.abs(resultatAttendu - z.getValeur());
            System.out.println("ERREUR : " + erreur);
            erreur_moyenne += erreur;
        }
        erreur_moyenne = erreur_moyenne/i;
        System.out.println("moyenne : " + erreur_moyenne);
        System.out.println("p4 : " + p4.getValeur());
        System.out.println("p5 : " + p5.getValeur());
    }
    
}
