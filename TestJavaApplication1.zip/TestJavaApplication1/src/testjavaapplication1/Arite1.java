/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Arite1 extends Operation {
    
    protected NonParametre operande;
    
    /*private static class Methode {
    }
    private Methode fct1 = new.Methode;
    private Methode fct2 = new.Methode;
    
    public Arite1(Parametre parametre, NonParametre operande, Methode fct1, Methode fct2) {
        super(parametre);
        this.operande = operande;
        this.operande.setParent(this);
        this.fct1 = fct1;
        this.fct2 = fct2;
    }*/
    
    public Arite1(Parametre parametre, NonParametre operande) {
        super(parametre);
        this.operande = operande;
        this.operande.setParent(this);
    }
    
    private float fct1(float x) {
        return (float) (1.0/x);
    }
    
    private float d_fct1(float x) {
        return (float) (1.0/(x*x));
    }
    private float fct2(float x) {
        //return (float)Math.sqrt(x);
        return x;
    }
    private float d_fct2(float x) {
        //return (float)Math.sqrt(x);
        return 1;
    }

    @Override
    float fctGradient(float x) {
        float a = this.parametre.getValeur();
        if (x != a)
            this.gradient = a*d_fct1(x) + (1-a)*d_fct2(x); 
        else 
            this.gradient = fct1(x) - fct2(x);
        return this.gradient;
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) return this.valeur; 
        else {
            float a = this.parametre.getValeur();
            float x = this.operande.getValeur();
            System.out.println(a + " * 1.0/" + x + " + (1" + (-a) + ") * " + x );
            this.valeur = a*fct1(x) + (1-a)*fct2(x);
            this.valeurCalclulee = true;
            return this.valeur;
        }
    }  
}
