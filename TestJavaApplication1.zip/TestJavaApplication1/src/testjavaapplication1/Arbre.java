/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public abstract class Arbre {
    protected float valeur;
    protected float gradient;
    abstract float fctGradient(float x);
    private Arbre parent;
    protected boolean valeurCalclulee;
    private boolean gradientCalcule;

    public Arbre() {
        this.valeurCalclulee = false;
        this.gradientCalcule = false;
    }
    
    abstract public float getValeur();

    protected void setParent(Arbre parent) {
        this.parent = parent;
    }
        
    protected float calculGradient(float resultatAttendu) {
        if (this.gradientCalcule) {
            return this.gradient;
        } else {
            if (this.parent == null) this.gradient = 2*(resultatAttendu - this.valeur);
            else this.gradient = this.fctGradient(this.valeur) * this.parent.calculGradient(resultatAttendu);
            this.gradientCalcule = true;
            //this.gradient = 1/(1+ (float) Math.pow(Math.E, - this.gradient * 2) - (float) 0.5) * 2;
            System.out.println(this.gradient);
            return this.gradient;
        }
    }
    
    protected void resetValeur() {
        this.valeurCalclulee = false;
        this.gradientCalcule = false;
        if (this.parent != null) this.parent.resetValeur();
    }
       
}
