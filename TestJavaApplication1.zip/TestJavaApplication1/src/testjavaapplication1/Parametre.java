
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Parametre extends Arbre {

    public Parametre() {
        super();
        this.valeur = (float)Math.random();
        this.valeurCalclulee = true;
    }
    
    @Override
    float fctGradient(float x) {
        //implenter le vrai truc!!!
        //return this.???????;
        return 1;
    }

    @Override
    public float getValeur() {
        return this.valeur;
    }
    
    public void update(float resultatAttendu) {
        this.resetValeur();
        this.valeur += this.calculGradient(resultatAttendu);
        this.valeur = 1/(1+ (float) Math.pow(Math.E, - this.valeur));
        this.valeurCalclulee = true;
    }

}
