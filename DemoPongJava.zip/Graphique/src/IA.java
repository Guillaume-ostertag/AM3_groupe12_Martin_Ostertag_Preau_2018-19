/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author garrprivate
 */
public class IA {
    
    private TableauNEntrees probasActions;
    private TableauNEntrees scores;
    private TableauNEntrees probasSituations;
    private int[] dimensionsObservations;
    private int[] dimensionsActions;
    private int nbActions;
    private int nbObservations;
    private int nbSituations;
    
    public IA(int nbObs, int nbAct, int resolution) {
        int dimensions[] = new int[2*nbObs + nbAct];
        
        for (int i = 0 ; i < dimensions.length ; i++) {
            dimensions[i] = resolution;
        }
        
        this.probasActions = new TableauNEntrees(dimensions);
        
        this.probasActions.SetValeurs((float)(1.0/Math.pow(resolution, nbObs)));
        this.nbActions = nbAct;
        this.nbObservations = nbObs;
        
        int observations[] = new int[nbObs];
        for (int i = 0 ; i < observations.length ; i++) {
            observations[i] = resolution;
        }
        
        this.dimensionsActions = new int[nbActions];
        for (int i = 0 ; i < this.dimensionsActions.length ; i++) {
            this.dimensionsActions[i] = resolution;
        }
        
        this.dimensionsObservations = new int[nbObs];
        System.arraycopy(observations, 0, this.dimensionsObservations, 0, this.dimensionsObservations.length);
        
        this.scores = new TableauNEntrees(observations);
        this.scores.SetValeurs(0);
    }
    
    public IA(int actions[], int observations[]) {
        int dimensions[] = this.MergeTabs(actions, observations, observations);
        
        this.probasActions = new TableauNEntrees(dimensions);
        
        this.dimensionsObservations = new int[observations.length];
        System.arraycopy(observations, 0, this.dimensionsObservations, 0, this.dimensionsObservations.length);
        
        this.dimensionsActions = new int[actions.length];
        System.arraycopy(actions, 0, this.dimensionsActions, 0, this.dimensionsActions.length);
        
        this.nbSituations = 1;
        for (int i = 0 ; i < observations.length ; i++) {
            this.nbSituations *= observations[i];
        }
        
        this.nbActions = actions.length;
        this.nbObservations = observations.length;

        this.probasActions.SetValeurs((float)(1.0/this.nbSituations));
        
        this.scores = new TableauNEntrees(observations);
        this.scores.SetValeurs(0);
        
        int[] dimensionSituParSitu = new int[2*observations.length];
        System.arraycopy(observations, 0, dimensionSituParSitu, 0, observations.length);
        System.arraycopy(observations, 0, dimensionSituParSitu, observations.length, observations.length);
        
        this.probasSituations = new TableauNEntrees(dimensionSituParSitu);
    }
    
    private int[] MergeTabs(int action[], int situationDepuis[], int situationVers[]) {
        int coordonees[] = new int[action.length + 2*situationVers.length];
        
        System.arraycopy(action, 0, coordonees, situationVers.length, action.length);
        System.arraycopy(situationDepuis, 0, coordonees, 0, situationVers.length); 
        System.arraycopy(situationVers, 0, coordonees, situationVers.length + action.length, situationVers.length);
        
        return coordonees;
    }
    
    private int[] MergeTabs(int action[], int situationDepuis[]) {
        int coordonees[] = new int[action.length + situationDepuis.length];
        
        System.arraycopy(action, 0, coordonees, this.nbObservations, this.nbActions);
        System.arraycopy(situationDepuis, 0, coordonees, 0, this.nbObservations);
        
        return coordonees;
    }
    
    public void SetValeursParDimension(int action[], int situationDepuis[], int situationVers[], float valeur) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            this.probasActions.SetValeursParDimension(coordonees, valeur);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
        }   
    } //test only!!
    
    public float GetValeursParDimension(int action[], int situationDepuis[], int situationVers[]) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            return this.probasActions.GetValeur(coordonees);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
            return 420;
        }   
    } //test only!!
    
    public void IncrementerProbaConditionnelle (int action[], int situationDepuis[], int situationVers[], float pas) {
        if (action.length == this.nbActions && situationDepuis.length == this.nbObservations && situationVers.length == this.nbObservations) {
            int coordonees[] = this.MergeTabs(action, situationDepuis, situationVers);
            float valeur = this.probasActions.GetValeur(coordonees) + pas;
            this.probasActions.SetValeursParDimension(coordonees, valeur);
            int coordonees2[] = this.MergeTabs(action, situationDepuis);
            this.probasActions.ChangeValeursDivisionParDimension(coordonees2, 1+pas);
        } else {
            System.out.println("ERROR! mauvaises tailles de tableau!!");
        }   
    }
    
    public void AfficherProbas(int action[], int situationDepuis[]) {
        int coordonees[] = this.MergeTabs(action, situationDepuis);
        this.probasActions.Affiche(coordonees);
    }
    
    public void AfficherScores() {
        this.scores.Affiche();
    }
    
    public void SetScore(int coordonees[], float valeur) {
        this.scores.SetValeursParDimension(coordonees, valeur);
    }
    
    public float GetScoreParActionParSituation(int action[], int situation[]) {
        if (action.length == this.nbActions && situation.length == this.nbObservations) {
            int coordonees[] = new int[this.nbObservations];
            
            for (int i = 0 ; i < coordonees.length ; i++) {
                coordonees[i] = 0;
            }
            
            float scoreProba = 0;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                                
                int coords[] = this.MergeTabs(action, situation, coordonees);
                float probabilite = this.probasActions.GetValeur(coords);
                float scoreSituation = this.scores.GetValeur(coordonees);

                scoreProba += probabilite * scoreSituation;
                //System.out.println(probabilite + " * " + scoreSituation + " = " + probabilite * scoreSituation + " => " + scoreProba);
                
                coordonees[cpt]++;
                while (cpt != coordonees.length && coordonees[cpt] == this.dimensionsObservations[cpt]) {
                    coordonees[cpt] = 0;
                    cpt++;
                    if (cpt == coordonees.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    coordonees[cpt]++;
                }
                
                cpt = 0;
            } while (!debordement);
            return scoreProba;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour les actions ou la situation!!");
            return 420;
        }
    }
    
    public int[] GetMeilleureActionParSituation(int[] situation) {
                
        if (situation.length == this.nbObservations) {

            int[] actions = new int[this.nbActions];
            int[] meilleuresActions = new int[this.nbActions];
            
            for (int i = 0 ; i < actions.length ; i++) {
                actions[i] = 0;
                meilleuresActions[i] = -1;
            }
            
            float meilleurScore = -420000;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                float score = this.GetScoreParActionParSituation(actions, situation);
                //System.out.println(score);
                if (score > meilleurScore || (int) (Math.random()*3) == 0 ) {
                    meilleurScore = score;
                    System.arraycopy(actions, 0, meilleuresActions, 0, meilleuresActions.length);
                }
                
                actions[cpt]++;
                while (cpt != actions.length && actions[cpt] == this.dimensionsActions[cpt]) {
                    actions[cpt] = 0;
                    cpt++;
                    if (cpt == actions.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    actions[cpt]++;
                }
                cpt = 0;
            } while (!debordement);
            //System.out.println(meilleurScore);
            return meilleuresActions;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour la situations!!");
            int tab[] = {-1};
            return tab;
        }
    }
    
    private float GetUneProbSituParSitu(int[] situationDepuis, int[] situationVers) {
        int[] actions = new int[this.dimensionsActions.length];
            
        for (int i = 0 ; i < actions.length ; i++) {
            actions[i] = 0;
        }
        
        int probaSituDepuisParSituVers = 0;
        
        int cpt = 0;
        int cpt2 = 0;
        boolean debordement = false;
           
        do {
            
            int coordonees[] = this.MergeTabs(actions, situationDepuis, situationVers);
            
            probaSituDepuisParSituVers += this.probasActions.GetValeur(coordonees);
            cpt2++;
            
            actions[cpt]++;
            while (cpt != actions.length && actions[cpt] == this.dimensionsActions[cpt]) {
                actions[cpt] = 0;
                cpt++;
                if (cpt == actions.length) {
                    debordement = true;
                    break; //pas genial wayoow
                }
                actions[cpt]++;
            }
            cpt = 0;
        } while (!debordement);
        
        return probaSituDepuisParSituVers /= cpt2;
    }
    
    public void updateProbaSituationsParSituations() {
        int[] situationParSituation = new int[this.dimensionsObservations.length*2];
        int[] dimensionsSituParSitu = new int[this.dimensionsObservations.length*2];
        System.arraycopy(this.dimensionsObservations, 0, dimensionsSituParSitu, 0, this.dimensionsObservations.length);
        System.arraycopy(this.dimensionsObservations, 0, dimensionsSituParSitu, this.dimensionsObservations.length, this.dimensionsObservations.length);
            
        for (int i = 0 ; i < situationParSituation.length ; i++) {
            situationParSituation[i] = 0;
        }
        
        int[] sutationsDepuis = new int[this.dimensionsObservations.length];
        int[] sutationsVers = new int[this.dimensionsObservations.length];
        
        int cpt = 0;
        boolean debordement = false;
           
        do {
            
            System.arraycopy(situationParSituation, 0, sutationsDepuis, 0, this.dimensionsObservations.length);
            System.arraycopy(situationParSituation, 0, sutationsVers, 0, this.dimensionsObservations.length);
            
            float proba = this.GetUneProbSituParSitu(sutationsDepuis, sutationsVers);
            
            this.probasSituations.SetValeursParDimension(situationParSituation, proba);
                        
            situationParSituation[cpt]++;
            while (cpt != situationParSituation.length && situationParSituation[cpt] == dimensionsSituParSitu[cpt]) {
                situationParSituation[cpt] = 0;
                cpt++;
                if (cpt == situationParSituation.length) {
                    debordement = true;
                    break; //pas genial wayoow
                }
                situationParSituation[cpt]++;
            }
            cpt = 0;
        } while (!debordement);
    }
    
    public float GetScoreParSituationRecursif(int[] situation, int R) {
        
        if (R <= 0) {
            //System.out.println("Bedrock");
            return this.scores.GetValeur(situation);
        }
        
        //System.out.println(";;;;;");
        
        int[] autresSituations = new int[this.dimensionsObservations.length];
        
        int[] situParSitu = new int[this.dimensionsObservations.length*2];
            
        for (int i = 0 ; i < autresSituations.length ; i++) {
            autresSituations[i] = 0;
        }
        
        int score = 0;
        
        int cpt = 0;
        boolean debordement = false;
           
        do {
            
            System.arraycopy(situation, 0, situParSitu, 0, situation.length);
            System.arraycopy(autresSituations, 0, situParSitu, situation.length, autresSituations.length);
            
            score += this.probasSituations.GetValeur(situParSitu) * GetScoreParSituationRecursif(autresSituations, R-1);
            
            autresSituations[cpt]++;
            while (cpt != autresSituations.length && autresSituations[cpt] == this.dimensionsObservations[cpt]) {
                autresSituations[cpt] = 0;
                cpt++;
                if (cpt == autresSituations.length) {
                    debordement = true;
                    break; //pas genial wayoow
                }
                autresSituations[cpt]++;
            }
            cpt = 0;
        } while (!debordement);
        
        return score;
    }
    
    public float GetScoreParActionParSituationRec(int action[], int situation[], int R) {
        if (action.length == this.nbActions && situation.length == this.nbObservations) {
            int coordonees[] = new int[this.nbObservations];
            
            for (int i = 0 ; i < coordonees.length ; i++) {
                coordonees[i] = 0;
            }
            
            float scoreProba = 0;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                                
                int coords[] = this.MergeTabs(action, situation, coordonees);
                float probabilite = this.probasActions.GetValeur(coords);
                float scoreSituation = this.GetScoreParSituationRecursif(coordonees, R);

                //System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
                
                scoreProba += probabilite * scoreSituation;
                //System.out.println(probabilite + " * " + scoreSituation + " = " + probabilite * scoreSituation + " => " + scoreProba);
                
                coordonees[cpt]++;
                while (cpt != coordonees.length && coordonees[cpt] == this.dimensionsObservations[cpt]) {
                    coordonees[cpt] = 0;
                    cpt++;
                    if (cpt == coordonees.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    coordonees[cpt]++;
                }
                
                cpt = 0;
            } while (!debordement);
            return scoreProba;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour les actions ou la situation!!");
            return 420;
        }
    }
    
    public int[] GetMeilleureActionParSituationRec(int[] situation, int R) {
        
        this.updateProbaSituationsParSituations();
                
        if (situation.length == this.nbObservations) {

            int[] actions = new int[this.nbActions];
            int[] meilleuresActions = new int[this.nbActions];
            
            for (int i = 0 ; i < actions.length ; i++) {
                actions[i] = 0;
                meilleuresActions[i] = -1;
            }
            
            float meilleurScore = -420000;
            int cpt = 0;
            boolean debordement = false;
            
            do {
                float score = this.GetScoreParActionParSituationRec(actions, situation, R);
                
                //System.out.println("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
                
                //System.out.println(score);
                if (score > meilleurScore || (int) (Math.random()*3) == 0 ) {
                    meilleurScore = score;
                    System.arraycopy(actions, 0, meilleuresActions, 0, meilleuresActions.length);
                }
                
                actions[cpt]++;
                while (cpt != actions.length && actions[cpt] == this.dimensionsActions[cpt]) {
                    actions[cpt] = 0;
                    cpt++;
                    if (cpt == actions.length) {
                        debordement = true;
                        break; //pas genial wayoow
                    }
                    actions[cpt]++;
                }
                cpt = 0;
            } while (!debordement);
            //System.out.println(meilleurScore);
            return meilleuresActions;
        } else {
            System.out.println("ERROR : mauvaises tailles de tableau pour la situations!!");
            int tab[] = {-1};
            return tab;
        }
    }
    
}
