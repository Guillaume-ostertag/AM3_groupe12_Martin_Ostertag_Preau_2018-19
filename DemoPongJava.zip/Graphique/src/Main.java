
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Miggy
 */
public class Main {
    public static void main (String[] args){
        
        int cpt = 0;
        
        int[] observation = {10,2,10,2,2};
        int[] action = {3};
        IA cerveau = new IA(action, observation);
        int [] observationPrec = new int [observation.length];
        int [] actionPrec = new int [action.length];
        int balleXprec = 0;
        int balleYprec = 0;
        
        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 10; k++) {
                    if (i == k){
                        int[] tab = {i,j,k};
                        cerveau.SetScore(tab, 1000);
                    }
//                    if (j == 0) {
//                        int[] tab = {i,j,k};
//                        cerveau.SetScore(tab, -10);
//                    }
                }
            }
        }
        
        Fenetre fen = new Fenetre();
       // fen.moveRect();
//        fen.repaint();
        while (true) {
           fen.Update();
           cpt++;
           if (cpt > 50) {
               cpt = 0;
                int w = fen.pan.getWidth()+1;

                 //System.out.println(w);

                observation[0] = (int) (fen.pan.n.getX()*10/w);
                observation[1] = ((fen.pan.n.getY() < fen.pan.b.getY()) ? 0 : 1);
                observation[2] = (int) (fen.pan.b.getX()*10/w);
                observation[3] = ((balleXprec < fen.pan.n.getX()) ? 0 : 1);
                observation[4] = ((balleYprec < fen.pan.n.getY()) ? 0 : 1);

                cerveau.IncrementerProbaConditionnelle(actionPrec, observationPrec, observation, (float)0.1);

                action = cerveau.GetMeilleureActionParSituation(observation);

                if((int) (Math.random()*500) == 0) action[0] = (int) (Math.random()*3);

                 System.out.println(Arrays.toString(action));
                 System.out.println(cerveau.GetScoreParActionParSituation(action, observation));

                 

                System.arraycopy(observation, 0, observationPrec, 0, observation.length);
                System.arraycopy(action, 0, actionPrec, 0, action.length);
                balleXprec = (int) fen.pan.n.getX();
                balleYprec = (int) fen.pan.n.getY();

             }
           
            switch (action[0]) {
                case 0:
                    fen.pan.b.deplaceBarre(-3, fen.pan);
                    break;
                case 1:
                    break;
                case 2:
                    fen.pan.b.deplaceBarre(3, fen.pan);
                    break;
                default:
                    break;
            }
           
        }
    }
}
