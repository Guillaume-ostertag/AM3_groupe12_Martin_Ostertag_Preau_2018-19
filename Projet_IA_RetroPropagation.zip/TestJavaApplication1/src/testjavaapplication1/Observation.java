/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Observation extends NonParametre {

    public Observation() {
        super();
    }

    @Override
    public float fctGradient(float x) {
        return 1;
    }
    
    @Override
    public float getValeur() {
        if (!this.valeurCalclulee) {
            System.out.println("blarg!");
            this.valeur = (float)Math.random();
        }
        return this.valeur;
    }

    public void setValeur(float valeur) {
        if (this.valeur != valeur) {
            this.resetValeur();
            this.valeur = valeur;
            this.valeurCalclulee = true;
        }
    }
    
}
