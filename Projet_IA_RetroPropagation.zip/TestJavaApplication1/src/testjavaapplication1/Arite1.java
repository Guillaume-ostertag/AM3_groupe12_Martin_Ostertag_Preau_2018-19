/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class Arite1 extends Operation {
    
    private NonParametre operande;
    
    public Arite1(Parametre parametre, NonParametre operande) {
        super(parametre);
        this.operande = operande;
        this.operande.setParent(this);
    }
    
    private float fct1(float x) {
        return (float) (1.0/x);
    }
    
    private float fct2(float x) {
        //return (float)Math.sqrt(x);
        return x;
    }

    @Override
    float fctGradient(float x) {
        return this.parametre.getValeur(); //???
    }

    @Override
    public float getValeur() {
        if (this.valeurCalclulee) return this.valeur; 
        else {
            float a = this.parametre.getValeur();
            float x = this.operande.getValeur();
            this.valeur = a*fct1(x) + (1-a)*fct2(x);
            this.valeurCalclulee = true;
            return this.valeur;
        }
    }
    
}
