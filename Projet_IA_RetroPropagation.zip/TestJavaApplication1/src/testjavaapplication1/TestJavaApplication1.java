/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testjavaapplication1;

/**
 *
 * @author garr
 */
public class TestJavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Observation x1 = new Observation();
        Observation x2 = new Observation();
        Parametre p1 = new Parametre();
        Parametre p2 = new Parametre();
        Arite1 a1_1 = new Arite1(p1, x1);
        Arite1 a1_2 = new Arite1(p2, x2);
        Parametre p3 = new Parametre();
        Arite2 y = new Arite2(p3, a1_1, a1_2);
        
        for (int i = 0 ; i < 1 ; i++) {
            x1.setValeur((float)Math.random());
            System.out.print("x1 : " + x1.getValeur());
            x2.setValeur((float)Math.random());
            System.out.println(" ; x2 : " + x2.getValeur());
            
            System.out.println(a1_1.getValeur());
            System.out.println(a1_2.getValeur());
            
            System.out.println("y : " + y.getValeur());
            System.out.println();
            System.out.println("//////");
            System.out.println();
            
            float resulstatAttendu = Math.max(x1.getValeur(), x2.getValeur());
            
            
        }
        
    }
    
}
