
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author garr
 */
public class Parametre extends Arbre {

    public Parametre() {
        super();
        this.valeur = (float)Math.random()*Arbre.range;
        //this.valeur = (float)(1/2.0);
        this.valeurCalclulee = true;
    }
    
    @Override
    float fctGradient() {
        Arbre parentTmp = this.parent;
        if (parentTmp instanceof Arite1) {
            Arite1 A = (Arite1)parentTmp;
            float x = A.operande.getValeur();
            return Arite1.op1.f.eval(x) - Arite1.op2.f.eval(x);
        } else if (parentTmp instanceof Arite2) {
            Arite2 A = (Arite2)parentTmp;
            float x1 = A.operande1.getValeur();
            float x2 = A.operande2.getValeur();
            return Arite2.op1.f.eval(x1,x2) - Arite2.op2.f.eval(x1,x2);
        } else {
            System.out.println("?????? (parametre fct gradient)");
            return 420;
        }
    }

    @Override
    public float getValeur() {
        return this.valeur;
    }
    
    public void update(float resultatAttendu) {
        this.gradient = this.calculGradient(resultatAttendu);
        this.resetValeur();
        //System.out.println(grad);
        this.gradient = (float) ((1/(0.5 + Math.pow(Math.E, -this.gradient/100) )) * Arbre.range);
        this.gradient *= 0.2; //0.5
        this.valeur += this.gradient;
        if (this.valeur < 0) this.valeur = 0;
        else if (this.valeur > Arbre.range) this.valeur = Arbre.range;
        this.valeurCalclulee = true; 
    }
    
    @Override
    public void resetValeur() {
        this.valeur = (float)Math.random()*Arbre.range;
        //this.valeur = (float)(1/2.0);
        this.valeurCalclulee = true;
    }

}
